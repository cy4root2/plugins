# -*- coding: utf-8 -*-




import os,sys,urlparse

from resources.lib.modules import control
from resources.lib.modules import trakt
inprogress_db = control.setting('inprogress_db')

sysaddon = sys.argv[0]

syshandle = int(sys.argv[1])

artPath = control.artPath()

addonFanart = control.addonFanart()

imdbCredentials = False if control.setting('imdb.user') == '' else True

traktCredentials = trakt.getTraktCredentialsInfo()

traktIndicators = trakt.getTraktIndicatorsInfo()

queueMenu = control.lang(32065).encode('utf-8')
############################################################################
	




class collectionBoxset:
    def collectionBoxset(self):
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]48 Hrs.[/COLOR] [COLOR ] (1982-1990)[/COLOR]', 'collections&url=fortyeighthours', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Ace Ventura[/COLOR] [COLOR ] (1994-1995)[/COLOR]', 'collections&url=aceventura', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Airplane[/COLOR] [COLOR ] (1980-1982)[/COLOR]', 'collections&url=airplane', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Airport[/COLOR] [COLOR ] (1970-1979)[/COLOR]', 'collections&url=airport', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]American Graffiti[/COLOR] [COLOR ] (1973-1979)[/COLOR]', 'collections&url=americangraffiti', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Anaconda[/COLOR] [COLOR ] (1997-2004)[/COLOR]', 'collections&url=anaconda', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Analyze This[/COLOR] [COLOR ] (1999-2002)[/COLOR]', 'collections&url=analyzethis', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Anchorman[/COLOR] [COLOR ] (2004-2013)[/COLOR]', 'collections&url=anchorman', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Austin Powers[/COLOR] [COLOR ] (1997-2002)[/COLOR]', 'collections&url=austinpowers', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Avengers[/COLOR] [COLOR ] (2008-2017)[/COLOR]', 'collections&url=avengers', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Back to the Future[/COLOR] [COLOR ] (1985-1990)[/COLOR]', 'collections&url=backtothefuture', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Bad Boys[/COLOR] [COLOR ] (1995-2003)[/COLOR]', 'collections&url=badboys', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Bad Santa[/COLOR] [COLOR ] (2003-2016)[/COLOR]', 'collections&url=badsanta', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Basic Instinct[/COLOR] [COLOR ] (1992-2006)[/COLOR]', 'collections&url=basicinstinct', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Batman[/COLOR] [COLOR ] (1989-2016)[/COLOR]', 'collections&url=batman', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Beverly Hills Cop[/COLOR] [COLOR ] (1984-1994)[/COLOR]', 'collections&url=beverlyhillscop', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Big Mommas House[/COLOR] [COLOR ] (2000-2011)[/COLOR]', 'collections&url=bigmommashouse', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Blues Brothers[/COLOR] [COLOR ] (1980-1998)[/COLOR]', 'collections&url=bluesbrothers', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Bourne[/COLOR] [COLOR ] (2002-2016)[/COLOR]', 'collections&url=bourne', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Bruce Almighty[/COLOR] [COLOR ] (2003-2007)[/COLOR]', 'collections&url=brucealmighty', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Caddyshack[/COLOR] [COLOR ] (1980-1988)[/COLOR]', 'collections&url=caddyshack', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Cheaper by the Dozen[/COLOR] [COLOR ] (2003-2005)[/COLOR]', 'collections&url=cheaperbythedozen', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Cheech and Chong[/COLOR] [COLOR ] (1978-1984)[/COLOR]', 'collections&url=cheechandchong', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Childs Play[/COLOR] [COLOR ] (1988-2004)[/COLOR]', 'collections&url=childsplay', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]City Slickers[/COLOR] [COLOR ] (1991-1994)[/COLOR]', 'collections&url=cityslickers', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Conan[/COLOR] [COLOR ] (1982-2011)[/COLOR]', 'collections&url=conan', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Crank[/COLOR] [COLOR ] (2006-2009)[/COLOR]', 'collections&url=crank', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Crocodile Dundee[/COLOR] [COLOR ] (1986-2001)[/COLOR]', 'collections&url=crodiledunde', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Da Vinci Code[/COLOR] [COLOR ] (2006-2017)[/COLOR]', 'collections&url=davincicode', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Daddy Day Care[/COLOR] [COLOR ] (2003-2007)[/COLOR]', 'collections&url=daddydaycare', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Dark Knight Trilogy[/COLOR] [COLOR ] (2005-2013)[/COLOR]', 'collections&url=darkknight', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Death Wish[/COLOR] [COLOR ] (1974-1994)[/COLOR]', 'collections&url=deathwish', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Delta Force[/COLOR] [COLOR ] (1986-1990)[/COLOR]', 'collections&url=deltaforce', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Die Hard[/COLOR] [COLOR ] (1988-2013)[/COLOR]', 'collections&url=diehard', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Dirty Dancing[/COLOR] [COLOR ] (1987-2004)[/COLOR]', 'collections&url=dirtydancing', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Dirty Harry[/COLOR] [COLOR ] (1971-1988)[/COLOR]', 'collections&url=dirtyharry', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Dumb and Dumber[/COLOR] [COLOR ] (1994-2014)[/COLOR]', 'collections&url=dumbanddumber', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Escape from New York[/COLOR] [COLOR ] (1981-1996)[/COLOR]', 'collections&url=escapefromnewyork', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Every Which Way But Loose[/COLOR] [COLOR ] (1978-1980)[/COLOR]', 'collections&url=everywhichwaybutloose', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Exorcist[/COLOR] [COLOR ] (1973-2005)[/COLOR]', 'collections&url=exorcist', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Expendables[/COLOR] [COLOR ] (2010-2014)[/COLOR]', 'collections&url=theexpendables', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Fantastic Four[/COLOR] [COLOR ] (2005-2015)[/COLOR]', 'collections&url=fantasticfour', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Fast and the Furious[/COLOR] [COLOR ] (2001-2017)[/COLOR]', 'collections&url=fastandthefurious', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Father of the Bride[/COLOR] [COLOR ] (1991-1995)[/COLOR]', 'collections&url=fatherofthebride', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Fletch[/COLOR] [COLOR ] (1985-1989)[/COLOR]', 'collections&url=fletch', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Friday[/COLOR] [COLOR ] (1995-2002)[/COLOR]', 'collections&url=friday', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Friday the 13th[/COLOR] [COLOR ] (1980-2009)[/COLOR]', 'collections&url=fridaythe13th', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Fugitive[/COLOR] [COLOR ] (1993-1998)[/COLOR]', 'collections&url=fugitive', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]G.I. Joe[/COLOR] [COLOR ] (2009-2013)[/COLOR]', 'collections&url=gijoe', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Get Shorty[/COLOR] [COLOR ] (1995-2005)[/COLOR]', 'collections&url=getshorty', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Gettysburg[/COLOR] [COLOR ] (1993-2003)[/COLOR]', 'collections&url=gettysburg', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Ghost Rider[/COLOR] [COLOR ] (2007-2011)[/COLOR]', 'collections&url=ghostrider', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Ghostbusters[/COLOR] [COLOR ] (1984-2016)[/COLOR]', 'collections&url=ghostbusters', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Gods Not Dead[/COLOR] [COLOR ] (2014-2016)[/COLOR]', 'collections&url=godsnotdead', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Godfather[/COLOR] [COLOR ] (1972-1990)[/COLOR]', 'collections&url=godfather', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Godzilla[/COLOR] [COLOR ] (1956-2016)[/COLOR]', 'collections&url=godzilla', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Grown Ups[/COLOR] [COLOR ] (2010-2013)[/COLOR]', 'collections&url=grownups', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Grumpy Old Men[/COLOR] [COLOR ] (2010-2013)[/COLOR]', 'collections&url=grumpyoldmen', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Guns of Navarone[/COLOR] [COLOR ] (1961-1978)[/COLOR]', 'collections&url=gunsofnavarone', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Halloween[/COLOR] [COLOR ] (1978-2009)[/COLOR]', 'collections&url=halloween', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hangover[/COLOR] [COLOR ] (2009-2013)[/COLOR]', 'collections&url=hangover', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hannibal Lector[/COLOR] [COLOR ] (1986-2007)[/COLOR]', 'collections&url=hanniballector', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hellraiser[/COLOR] [COLOR ] (1987-1996)[/COLOR]', 'collections&url=hellraiser', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Honey I Shrunk the Kids[/COLOR] [COLOR ] (1989-1995)[/COLOR]', 'collections&url=honeyishrunkthekids', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Horrible Bosses[/COLOR] [COLOR ] (2011-2014)[/COLOR]', 'collections&url=horriblebosses', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hostel[/COLOR] [COLOR ] (2005-2011)[/COLOR]', 'collections&url=hostel', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hot Shots[/COLOR] [COLOR ] (1991-1996)[/COLOR]', 'collections&url=hotshots', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hulk[/COLOR] [COLOR ] (2003-2008)[/COLOR]', 'collections&url=hulk', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Independence Day[/COLOR] [COLOR ] (1996-2016)[/COLOR]', 'collections&url=independenceday', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Indiana Jones[/COLOR] [COLOR ] (1981-2008)[/COLOR]', 'collections&url=indianajones', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Insidious[/COLOR] [COLOR ] (2010-2015)[/COLOR]', 'collections&url=insidious', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Iron Eagle[/COLOR] [COLOR ] (1986-1992)[/COLOR]', 'collections&url=ironeagle', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Iron Man[/COLOR] [COLOR ] (2008-2013)[/COLOR]', 'collections&url=ironman', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jack Reacher[/COLOR] [COLOR ] (2012-2016)[/COLOR]', 'collections&url=jackreacher', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jack Ryan[/COLOR] [COLOR ] (1990-2014)[/COLOR]', 'collections&url=jackryan', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jackass[/COLOR] [COLOR ] (2002-2013)[/COLOR]', 'collections&url=jackass', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]James Bond[/COLOR] [COLOR ] (1963-2015)[/COLOR]', 'collections&url=jamesbond', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jaws[/COLOR] [COLOR ] (1975-1987)[/COLOR]', 'collections&url=jaws', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jeepers Creepers[/COLOR] [COLOR ] (2001-2017)[/COLOR]', 'collections&url=jeeperscreepers', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]John Wick[/COLOR] [COLOR ] (2014-2017)[/COLOR]', 'collections&url=johnwick', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jumanji[/COLOR] [COLOR ] (1995-2005)[/COLOR]', 'collections&url=jumanji', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jurassic Park[/COLOR] [COLOR ] (1993-2015)[/COLOR]', 'collections&url=jurassicpark', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Kick-Ass[/COLOR] [COLOR ] (2010-2013)[/COLOR]', 'collections&url=kickass', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Kill Bill[/COLOR] [COLOR ] (2003-2004)[/COLOR]', 'collections&url=killbill', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]King Kong[/COLOR] [COLOR ] (1933-2016)[/COLOR]', 'collections&url=kingkong', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Lara Croft[/COLOR] [COLOR ] (2001-2003)[/COLOR]', 'collections&url=laracroft', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Legally Blonde[/COLOR] [COLOR ] (2001-2003)[/COLOR]', 'collections&url=legallyblonde', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Lethal Weapon[/COLOR] [COLOR ] (1987-1998)[/COLOR]', 'collections&url=leathalweapon', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Look Whos Talking[/COLOR] [COLOR ] (1989-1993)[/COLOR]', 'collections&url=lookwhostalking', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Machete[/COLOR] [COLOR ] (2010-2013)[/COLOR]', 'collections&url=machete', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Magic Mike[/COLOR] [COLOR ] (2012-2015)[/COLOR]', 'collections&url=magicmike', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Major League[/COLOR] [COLOR ] (1989-1998)[/COLOR]', 'collections&url=majorleague', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Man from Snowy River[/COLOR] [COLOR ] (1982-1988)[/COLOR]', 'collections&url=manfromsnowyriver', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Mask[/COLOR] [COLOR ] (1994-2005)[/COLOR]', 'collections&url=mask', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Matrix[/COLOR] [COLOR ] (1999-2003)[/COLOR]', 'collections&url=matrix', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Mechanic[/COLOR] [COLOR ] (2011-2016)[/COLOR]', 'collections&url=themechanic', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Meet the Parents[/COLOR] [COLOR ] (2000-2010)[/COLOR]', 'collections&url=meettheparents', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Men in Black[/COLOR] [COLOR ] (1997-2012)[/COLOR]', 'collections&url=meninblack', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Mighty Ducks[/COLOR] [COLOR ] (1995-1996)[/COLOR]', 'collections&url=mightyducks', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Miss Congeniality[/COLOR] [COLOR ] (2000-2005)[/COLOR]', 'collections&url=misscongeniality', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Missing in Action[/COLOR] [COLOR ] (1984-1988)[/COLOR]', 'collections&url=missinginaction', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Mission Impossible[/COLOR] [COLOR ] (1996-2015)[/COLOR]', 'collections&url=missionimpossible', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Naked Gun[/COLOR] [COLOR ] (1988-1994)[/COLOR]', 'collections&url=nakedgun', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]National Lampoon[/COLOR] [COLOR ] (1978-2006)[/COLOR]', 'collections&url=nationallampoon', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]National Lampoons Vacation[/COLOR] [COLOR ] (1983-2015)[/COLOR]', 'collections&url=nationallampoonsvacation', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]National Treasure[/COLOR] [COLOR ] (2004-2007)[/COLOR]', 'collections&url=nationaltreasure', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Neighbors[/COLOR] [COLOR ] (2014-2016)[/COLOR]', 'collections&url=neighbors', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Night at the Museum[/COLOR] [COLOR ] (2006-2014)[/COLOR]', 'collections&url=nightatthemuseum', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Nightmare on Elm Street[/COLOR] [COLOR ] (1984-2010)[/COLOR]', 'collections&url=nightmareonelmstreet', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Now You See Me[/COLOR] [COLOR ] (2013-2016)[/COLOR]', 'collections&url=nowyouseeme', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Nutty Professor[/COLOR] [COLOR ] (1996-2000)[/COLOR]', 'collections&url=nuttyprofessor', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Oceans Eleven[/COLOR] [COLOR ] (2001-2007)[/COLOR]', 'collections&url=oceanseleven', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Odd Couple[/COLOR] [COLOR ] (1968-1998)[/COLOR]', 'collections&url=oddcouple', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Oh, God[/COLOR] [COLOR ] (1977-1984)[/COLOR]', 'collections&url=ohgod', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Olympus Has Fallen[/COLOR] [COLOR ] (2013-2016)[/COLOR]', 'collections&url=olympushasfallen', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Omen[/COLOR] [COLOR ] (1976-1981)[/COLOR]', 'collections&url=omen', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Paul Blart Mall Cop[/COLOR] [COLOR ] (2009-2015)[/COLOR]', 'collections&url=paulblart', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Pirates of the Caribbean[/COLOR] [COLOR ] (2003-2017)[/COLOR]', 'collections&url=piratesofthecaribbean', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Planet of the Apes[/COLOR] [COLOR ] (1968-2014)[/COLOR]', 'collections&url=planetoftheapes', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Police Academy[/COLOR] [COLOR ] (1984-1994)[/COLOR]', 'collections&url=policeacademy', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Poltergeist[/COLOR] [COLOR ] (1982-1988)[/COLOR]', 'collections&url=postergeist', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Porkys[/COLOR] [COLOR ] (1981-1985)[/COLOR]', 'collections&url=porkys', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Predator[/COLOR] [COLOR ] (1987-2010)[/COLOR]', 'collections&url=predator', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Purge[/COLOR] [COLOR ] (2013-2016)[/COLOR]', 'collections&url=thepurge', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Rambo[/COLOR] [COLOR ] (1982-2008)[/COLOR]', 'collections&url=rambo', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]RED[/COLOR] [COLOR ] (2010-2013)[/COLOR]', 'collections&url=red', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Revenge of the Nerds[/COLOR] [COLOR ] (1984-1987)[/COLOR]', 'collections&url=revengeofthenerds', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Riddick[/COLOR] [COLOR ] (2000-2013)[/COLOR]', 'collections&url=riddick', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Ride Along[/COLOR] [COLOR ] (2014-2016)[/COLOR]', 'collections&url=ridealong', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Ring[/COLOR] [COLOR ] (2002-2017)[/COLOR]', 'collections&url=thering', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]RoboCop[/COLOR] [COLOR ] (1987-1993)[/COLOR]', 'collections&url=robocop', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Rocky[/COLOR] [COLOR ] (1976-2015)[/COLOR]', 'collections&url=rocky', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Romancing the Stone[/COLOR] [COLOR ] (1984-1985)[/COLOR]', 'collections&url=romancingthestone', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Rush Hour[/COLOR] [COLOR ] (1998-2007)[/COLOR]', 'collections&url=rushhour', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Santa Clause[/COLOR] [COLOR ] (1994-2006)[/COLOR]', 'collections&url=santaclause', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Saw[/COLOR] [COLOR ] (2004-2010)[/COLOR]', 'collections&url=saw', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Sex and the City[/COLOR] [COLOR ] (2008-2010)[/COLOR]', 'collections&url=sexandthecity', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Shaft[/COLOR] [COLOR ] (1971-2000)[/COLOR]', 'collections&url=shaft', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Shanghai Noon[/COLOR] [COLOR ] (2000-2003)[/COLOR]', 'collections&url=shanghainoon', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Sin City[/COLOR] [COLOR ] (2005-2014)[/COLOR]', 'collections&url=sincity', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Sinister[/COLOR] [COLOR ] (2012-2015)[/COLOR]', 'collections&url=sinister', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Sister Act[/COLOR] [COLOR ] (1995-1993)[/COLOR]', 'collections&url=sisteract', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Smokey and the Bandit[/COLOR] [COLOR ] (1977-1986)[/COLOR]', 'collections&url=smokeyandthebandit', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Speed[/COLOR] [COLOR ] (1994-1997)[/COLOR]', 'collections&url=speed', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Spider-Man[/COLOR] [COLOR ] (2002-2017)[/COLOR]', 'collections&url=spiderman', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Stakeout[/COLOR] [COLOR ] (1987-1993)[/COLOR]', 'collections&url=stakeout', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Star Trek[/COLOR] [COLOR ] (1979-2016)[/COLOR]', 'collections&url=startrek', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Star Wars[/COLOR] [COLOR ] (1977-2015)[/COLOR]', 'collections&url=starwars', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Superman[/COLOR] [COLOR ] (1978-2016)[/COLOR]', 'collections&url=superman', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Sting[/COLOR] [COLOR ] (1973-1983)[/COLOR]', 'collections&url=thesting', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Taken[/COLOR] [COLOR ] (2008-2014)[/COLOR]', 'collections&url=taken', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Taxi[/COLOR] [COLOR ] (1998-2007)[/COLOR]', 'collections&url=taxi', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Ted[/COLOR] [COLOR ] (2012-2015)[/COLOR]', 'collections&url=ted', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Teen Wolf[/COLOR] [COLOR ] (1985-1987)[/COLOR]', 'collections&url=teenwolf', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Terminator[/COLOR] [COLOR ] (1984-2015)[/COLOR]', 'collections&url=terminator', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Terms of Endearment[/COLOR] [COLOR ] (1983-1996)[/COLOR]', 'collections&url=termsofendearment', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Texas Chainsaw Massacre[/COLOR] [COLOR ] (1974-2013)[/COLOR]', 'collections&url=texaschainsawmassacre', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Thing[/COLOR] [COLOR ] (1982-2011)[/COLOR]', 'collections&url=thething', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Thomas Crown Affair[/COLOR] [COLOR ] (1968-1999)[/COLOR]', 'collections&url=thomascrownaffair', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Transporter[/COLOR] [COLOR ] (2002-2015)[/COLOR]', 'collections&url=transporter', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Under Siege[/COLOR] [COLOR ] (1992-1995)[/COLOR]', 'collections&url=undersiege', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Universal Soldier[/COLOR] [COLOR ] (1992-2012)[/COLOR]', 'collections&url=universalsoldier', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Wall Street[/COLOR] [COLOR ] (1987-2010)[/COLOR]', 'collections&url=wallstreet', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Waynes World[/COLOR] [COLOR ] (1992-1993)[/COLOR]', 'collections&url=waynesworld', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Weekend at Bernies[/COLOR] [COLOR ] (1989-1993)[/COLOR]', 'collections&url=weekendatbernies', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Whole Nine Yards[/COLOR] [COLOR ] (2000-2004)[/COLOR]', 'collections&url=wholenineyards', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]X-Files[/COLOR] [COLOR ] (1998-2008)[/COLOR]', 'collections&url=xfiles', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]X-Men[/COLOR] [COLOR ] (2000-2016)[/COLOR]', 'collections&url=xmen', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]xXx[/COLOR] [COLOR ] (2002-2005)[/COLOR]', 'collections&url=xxx', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Young Guns[/COLOR] [COLOR ] (1988-1990)[/COLOR]', 'collections&url=youngguns', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Zoolander[/COLOR] [COLOR ] (2001-2016)[/COLOR]', 'collections&url=zoolander', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Zorro[/COLOR] [COLOR ] (1998-2005)[/COLOR]', 'collections&url=zorro', 'tmdb2.png', 'DefaultRecentlyAddedMovies.png')
	self.endDirectory()
		







##########################################################################################################
    def addDirectoryItem(self, name, query, thumb, icon, queue=False, isAction=True, isFolder=True):     #
        try: name = control.lang(name).encode('utf-8')							 #
        except: pass											 #
        url = '%s?action=%s' % (sysaddon, query) if isAction == True else query				 #
        thumb = os.path.join(artPath, thumb) if not artPath == None else icon				 #
        cm = []												 #
        if queue == True: cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))		 #
        item = control.item(label=name)									 #
        item.addContextMenuItems(cm)									 #
        item.setArt({'icon': thumb, 'thumb': thumb})							 #
        if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)			 #
        control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)			 #
    def endDirectory(self):										 #
        control.directory(syshandle, cacheToDisc=True)							 #
##########################################################################################################

