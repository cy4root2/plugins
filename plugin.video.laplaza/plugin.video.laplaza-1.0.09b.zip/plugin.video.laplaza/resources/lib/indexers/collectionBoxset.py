# -*- coding: utf-8 -*-




import os,sys,urlparse

from resources.lib.modules import control
from resources.lib.modules import trakt
inprogress_db = control.setting('inprogress_db')

sysaddon = sys.argv[0]

syshandle = int(sys.argv[1])

artPath = control.artPath()

addonFanart = control.addonFanart()

imdbCredentials = False if control.setting('imdb.user') == '' else True

traktCredentials = trakt.getTraktCredentialsInfo()

traktIndicators = trakt.getTraktIndicatorsInfo()

queueMenu = control.lang(32065).encode('utf-8')
############################################################################
	




class collectionBoxset:
    def collectionBoxset(self):
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]48 Hrs.[/COLOR] [COLOR ] (1982-1990)[/COLOR]', 'collections&url=fortyeighthours', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Ace Ventura[/COLOR] [COLOR ] (1994-1995)[/COLOR]', 'collections&url=aceventura', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Airplane[/COLOR] [COLOR ] (1980-1982)[/COLOR]', 'collections&url=airplane', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Airport[/COLOR] [COLOR ] (1970-1979)[/COLOR]', 'collections&url=airport', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]American Graffiti[/COLOR] [COLOR ] (1973-1979)[/COLOR]', 'collections&url=americangraffiti', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Anaconda[/COLOR] [COLOR ] (1997-2004)[/COLOR]', 'collections&url=anaconda', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Analyze This[/COLOR] [COLOR ] (1999-2002)[/COLOR]', 'collections&url=analyzethis', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Anchorman[/COLOR] [COLOR ] (2004-2013)[/COLOR]', 'collections&url=anchorman', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Austin Powers[/COLOR] [COLOR ] (1997-2002)[/COLOR]', 'collections&url=austinpowers', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Avengers[/COLOR] [COLOR ] (2008-2017)[/COLOR]', 'collections&url=avengers', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Back to the Future[/COLOR] [COLOR ] (1985-1990)[/COLOR]', 'collections&url=backtothefuture', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Bad Boys[/COLOR] [COLOR ] (1995-2003)[/COLOR]', 'collections&url=badboys', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Bad Santa[/COLOR] [COLOR ] (2003-2016)[/COLOR]', 'collections&url=badsanta', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Basic Instinct[/COLOR] [COLOR ] (1992-2006)[/COLOR]', 'collections&url=basicinstinct', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Batman[/COLOR] [COLOR ] (1989-2016)[/COLOR]', 'collections&url=batman', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Beverly Hills Cop[/COLOR] [COLOR ] (1984-1994)[/COLOR]', 'collections&url=beverlyhillscop', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Big Mommas House[/COLOR] [COLOR ] (2000-2011)[/COLOR]', 'collections&url=bigmommashouse', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Blues Brothers[/COLOR] [COLOR ] (1980-1998)[/COLOR]', 'collections&url=bluesbrothers', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Bourne[/COLOR] [COLOR ] (2002-2016)[/COLOR]', 'collections&url=bourne', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Bruce Almighty[/COLOR] [COLOR ] (2003-2007)[/COLOR]', 'collections&url=brucealmighty', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Caddyshack[/COLOR] [COLOR ] (1980-1988)[/COLOR]', 'collections&url=caddyshack', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Cheaper by the Dozen[/COLOR] [COLOR ] (2003-2005)[/COLOR]', 'collections&url=cheaperbythedozen', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Cheech and Chong[/COLOR] [COLOR ] (1978-1984)[/COLOR]', 'collections&url=cheechandchong', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Childs Play[/COLOR] [COLOR ] (1988-2004)[/COLOR]', 'collections&url=childsplay', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]City Slickers[/COLOR] [COLOR ] (1991-1994)[/COLOR]', 'collections&url=cityslickers', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Conan[/COLOR] [COLOR ] (1982-2011)[/COLOR]', 'collections&url=conan', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Crank[/COLOR] [COLOR ] (2006-2009)[/COLOR]', 'collections&url=crank', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Crocodile Dundee[/COLOR] [COLOR ] (1986-2001)[/COLOR]', 'collections&url=crodiledunde', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Da Vinci Code[/COLOR] [COLOR ] (2006-2017)[/COLOR]', 'collections&url=davincicode', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Daddy Day Care[/COLOR] [COLOR ] (2003-2007)[/COLOR]', 'collections&url=daddydaycare', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Dark Knight Trilogy[/COLOR] [COLOR ] (2005-2013)[/COLOR]', 'collections&url=darkknight', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Death Wish[/COLOR] [COLOR ] (1974-1994)[/COLOR]', 'collections&url=deathwish', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Delta Force[/COLOR] [COLOR ] (1986-1990)[/COLOR]', 'collections&url=deltaforce', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Die Hard[/COLOR] [COLOR ] (1988-2013)[/COLOR]', 'collections&url=diehard', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Dirty Dancing[/COLOR] [COLOR ] (1987-2004)[/COLOR]', 'collections&url=dirtydancing', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Dirty Harry[/COLOR] [COLOR ] (1971-1988)[/COLOR]', 'collections&url=dirtyharry', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Dumb and Dumber[/COLOR] [COLOR ] (1994-2014)[/COLOR]', 'collections&url=dumbanddumber', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Escape from New York[/COLOR] [COLOR ] (1981-1996)[/COLOR]', 'collections&url=escapefromnewyork', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Every Which Way But Loose[/COLOR] [COLOR ] (1978-1980)[/COLOR]', 'collections&url=everywhichwaybutloose', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Exorcist[/COLOR] [COLOR ] (1973-2005)[/COLOR]', 'collections&url=exorcist', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Expendables[/COLOR] [COLOR ] (2010-2014)[/COLOR]', 'collections&url=theexpendables', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Fantastic Four[/COLOR] [COLOR ] (2005-2015)[/COLOR]', 'collections&url=fantasticfour', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Fast and the Furious[/COLOR] [COLOR ] (2001-2017)[/COLOR]', 'collections&url=fastandthefurious', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Father of the Bride[/COLOR] [COLOR ] (1991-1995)[/COLOR]', 'collections&url=fatherofthebride', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Fletch[/COLOR] [COLOR ] (1985-1989)[/COLOR]', 'collections&url=fletch', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Friday[/COLOR] [COLOR ] (1995-2002)[/COLOR]', 'collections&url=friday', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Friday the 13th[/COLOR] [COLOR ] (1980-2009)[/COLOR]', 'collections&url=fridaythe13th', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Fugitive[/COLOR] [COLOR ] (1993-1998)[/COLOR]', 'collections&url=fugitive', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]G.I. Joe[/COLOR] [COLOR ] (2009-2013)[/COLOR]', 'collections&url=gijoe', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Get Shorty[/COLOR] [COLOR ] (1995-2005)[/COLOR]', 'collections&url=getshorty', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Gettysburg[/COLOR] [COLOR ] (1993-2003)[/COLOR]', 'collections&url=gettysburg', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Ghost Rider[/COLOR] [COLOR ] (2007-2011)[/COLOR]', 'collections&url=ghostrider', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Ghostbusters[/COLOR] [COLOR ] (1984-2016)[/COLOR]', 'collections&url=ghostbusters', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Gods Not Dead[/COLOR] [COLOR ] (2014-2016)[/COLOR]', 'collections&url=godsnotdead', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Godfather[/COLOR] [COLOR ] (1972-1990)[/COLOR]', 'collections&url=godfather', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Godzilla[/COLOR] [COLOR ] (1956-2016)[/COLOR]', 'collections&url=godzilla', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Grown Ups[/COLOR] [COLOR ] (2010-2013)[/COLOR]', 'collections&url=grownups', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Grumpy Old Men[/COLOR] [COLOR ] (2010-2013)[/COLOR]', 'collections&url=grumpyoldmen', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Guns of Navarone[/COLOR] [COLOR ] (1961-1978)[/COLOR]', 'collections&url=gunsofnavarone', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Halloween[/COLOR] [COLOR ] (1978-2009)[/COLOR]', 'collections&url=halloween', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hangover[/COLOR] [COLOR ] (2009-2013)[/COLOR]', 'collections&url=hangover', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hannibal Lector[/COLOR] [COLOR ] (1986-2007)[/COLOR]', 'collections&url=hanniballector', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hellraiser[/COLOR] [COLOR ] (1987-1996)[/COLOR]', 'collections&url=hellraiser', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Honey I Shrunk the Kids[/COLOR] [COLOR ] (1989-1995)[/COLOR]', 'collections&url=honeyishrunkthekids', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Horrible Bosses[/COLOR] [COLOR ] (2011-2014)[/COLOR]', 'collections&url=horriblebosses', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hostel[/COLOR] [COLOR ] (2005-2011)[/COLOR]', 'collections&url=hostel', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hot Shots[/COLOR] [COLOR ] (1991-1996)[/COLOR]', 'collections&url=hotshots', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Hulk[/COLOR] [COLOR ] (2003-2008)[/COLOR]', 'collections&url=hulk', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Independence Day[/COLOR] [COLOR ] (1996-2016)[/COLOR]', 'collections&url=independenceday', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Indiana Jones[/COLOR] [COLOR ] (1981-2008)[/COLOR]', 'collections&url=indianajones', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Insidious[/COLOR] [COLOR ] (2010-2015)[/COLOR]', 'collections&url=insidious', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Iron Eagle[/COLOR] [COLOR ] (1986-1992)[/COLOR]', 'collections&url=ironeagle', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Iron Man[/COLOR] [COLOR ] (2008-2013)[/COLOR]', 'collections&url=ironman', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jack Reacher[/COLOR] [COLOR ] (2012-2016)[/COLOR]', 'collections&url=jackreacher', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jack Ryan[/COLOR] [COLOR ] (1990-2014)[/COLOR]', 'collections&url=jackryan', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jackass[/COLOR] [COLOR ] (2002-2013)[/COLOR]', 'collections&url=jackass', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]James Bond[/COLOR] [COLOR ] (1963-2015)[/COLOR]', 'collections&url=jamesbond', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jaws[/COLOR] [COLOR ] (1975-1987)[/COLOR]', 'collections&url=jaws', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jeepers Creepers[/COLOR] [COLOR ] (2001-2017)[/COLOR]', 'collections&url=jeeperscreepers', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]John Wick[/COLOR] [COLOR ] (2014-2017)[/COLOR]', 'collections&url=johnwick', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jumanji[/COLOR] [COLOR ] (1995-2005)[/COLOR]', 'collections&url=jumanji', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Jurassic Park[/COLOR] [COLOR ] (1993-2015)[/COLOR]', 'collections&url=jurassicpark', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Kick-Ass[/COLOR] [COLOR ] (2010-2013)[/COLOR]', 'collections&url=kickass', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Kill Bill[/COLOR] [COLOR ] (2003-2004)[/COLOR]', 'collections&url=killbill', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]King Kong[/COLOR] [COLOR ] (1933-2016)[/COLOR]', 'collections&url=kingkong', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Lara Croft[/COLOR] [COLOR ] (2001-2003)[/COLOR]', 'collections&url=laracroft', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Legally Blonde[/COLOR] [COLOR ] (2001-2003)[/COLOR]', 'collections&url=legallyblonde', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Lethal Weapon[/COLOR] [COLOR ] (1987-1998)[/COLOR]', 'collections&url=leathalweapon', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Look Whos Talking[/COLOR] [COLOR ] (1989-1993)[/COLOR]', 'collections&url=lookwhostalking', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Machete[/COLOR] [COLOR ] (2010-2013)[/COLOR]', 'collections&url=machete', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Magic Mike[/COLOR] [COLOR ] (2012-2015)[/COLOR]', 'collections&url=magicmike', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Major League[/COLOR] [COLOR ] (1989-1998)[/COLOR]', 'collections&url=majorleague', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Man from Snowy River[/COLOR] [COLOR ] (1982-1988)[/COLOR]', 'collections&url=manfromsnowyriver', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Mask[/COLOR] [COLOR ] (1994-2005)[/COLOR]', 'collections&url=mask', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Matrix[/COLOR] [COLOR ] (1999-2003)[/COLOR]', 'collections&url=matrix', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Mechanic[/COLOR] [COLOR ] (2011-2016)[/COLOR]', 'collections&url=themechanic', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Meet the Parents[/COLOR] [COLOR ] (2000-2010)[/COLOR]', 'collections&url=meettheparents', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Men in Black[/COLOR] [COLOR ] (1997-2012)[/COLOR]', 'collections&url=meninblack', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Mighty Ducks[/COLOR] [COLOR ] (1995-1996)[/COLOR]', 'collections&url=mightyducks', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Miss Congeniality[/COLOR] [COLOR ] (2000-2005)[/COLOR]', 'collections&url=misscongeniality', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Missing in Action[/COLOR] [COLOR ] (1984-1988)[/COLOR]', 'collections&url=missinginaction', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Mission Impossible[/COLOR] [COLOR ] (1996-2015)[/COLOR]', 'collections&url=missionimpossible', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Naked Gun[/COLOR] [COLOR ] (1988-1994)[/COLOR]', 'collections&url=nakedgun', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]National Lampoon[/COLOR] [COLOR ] (1978-2006)[/COLOR]', 'collections&url=nationallampoon', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]National Lampoons Vacation[/COLOR] [COLOR ] (1983-2015)[/COLOR]', 'collections&url=nationallampoonsvacation', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]National Treasure[/COLOR] [COLOR ] (2004-2007)[/COLOR]', 'collections&url=nationaltreasure', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Neighbors[/COLOR] [COLOR ] (2014-2016)[/COLOR]', 'collections&url=neighbors', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Night at the Museum[/COLOR] [COLOR ] (2006-2014)[/COLOR]', 'collections&url=nightatthemuseum', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Nightmare on Elm Street[/COLOR] [COLOR ] (1984-2010)[/COLOR]', 'collections&url=nightmareonelmstreet', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Now You See Me[/COLOR] [COLOR ] (2013-2016)[/COLOR]', 'collections&url=nowyouseeme', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Nutty Professor[/COLOR] [COLOR ] (1996-2000)[/COLOR]', 'collections&url=nuttyprofessor', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Oceans Eleven[/COLOR] [COLOR ] (2001-2007)[/COLOR]', 'collections&url=oceanseleven', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Odd Couple[/COLOR] [COLOR ] (1968-1998)[/COLOR]', 'collections&url=oddcouple', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Oh, God[/COLOR] [COLOR ] (1977-1984)[/COLOR]', 'collections&url=ohgod', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Olympus Has Fallen[/COLOR] [COLOR ] (2013-2016)[/COLOR]', 'collections&url=olympushasfallen', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Omen[/COLOR] [COLOR ] (1976-1981)[/COLOR]', 'collections&url=omen', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Paul Blart Mall Cop[/COLOR] [COLOR ] (2009-2015)[/COLOR]', 'collections&url=paulblart', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Pirates of the Caribbean[/COLOR] [COLOR ] (2003-2017)[/COLOR]', 'collections&url=piratesofthecaribbean', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Planet of the Apes[/COLOR] [COLOR ] (1968-2014)[/COLOR]', 'collections&url=planetoftheapes', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Police Academy[/COLOR] [COLOR ] (1984-1994)[/COLOR]', 'collections&url=policeacademy', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Poltergeist[/COLOR] [COLOR ] (1982-1988)[/COLOR]', 'collections&url=postergeist', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Porkys[/COLOR] [COLOR ] (1981-1985)[/COLOR]', 'collections&url=porkys', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Predator[/COLOR] [COLOR ] (1987-2010)[/COLOR]', 'collections&url=predator', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Purge[/COLOR] [COLOR ] (2013-2016)[/COLOR]', 'collections&url=thepurge', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Rambo[/COLOR] [COLOR ] (1982-2008)[/COLOR]', 'collections&url=rambo', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]RED[/COLOR] [COLOR ] (2010-2013)[/COLOR]', 'collections&url=red', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Revenge of the Nerds[/COLOR] [COLOR ] (1984-1987)[/COLOR]', 'collections&url=revengeofthenerds', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Riddick[/COLOR] [COLOR ] (2000-2013)[/COLOR]', 'collections&url=riddick', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Ride Along[/COLOR] [COLOR ] (2014-2016)[/COLOR]', 'collections&url=ridealong', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Ring[/COLOR] [COLOR ] (2002-2017)[/COLOR]', 'collections&url=thering', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]RoboCop[/COLOR] [COLOR ] (1987-1993)[/COLOR]', 'collections&url=robocop', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Rocky[/COLOR] [COLOR ] (1976-2015)[/COLOR]', 'collections&url=rocky', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Romancing the Stone[/COLOR] [COLOR ] (1984-1985)[/COLOR]', 'collections&url=romancingthestone', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Rush Hour[/COLOR] [COLOR ] (1998-2007)[/COLOR]', 'collections&url=rushhour', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Santa Clause[/COLOR] [COLOR ] (1994-2006)[/COLOR]', 'collections&url=santaclause', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Saw[/COLOR] [COLOR ] (2004-2010)[/COLOR]', 'collections&url=saw', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Sex and the City[/COLOR] [COLOR ] (2008-2010)[/COLOR]', 'collections&url=sexandthecity', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Shaft[/COLOR] [COLOR ] (1971-2000)[/COLOR]', 'collections&url=shaft', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Shanghai Noon[/COLOR] [COLOR ] (2000-2003)[/COLOR]', 'collections&url=shanghainoon', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Sin City[/COLOR] [COLOR ] (2005-2014)[/COLOR]', 'collections&url=sincity', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Sinister[/COLOR] [COLOR ] (2012-2015)[/COLOR]', 'collections&url=sinister', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Sister Act[/COLOR] [COLOR ] (1995-1993)[/COLOR]', 'collections&url=sisteract', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Smokey and the Bandit[/COLOR] [COLOR ] (1977-1986)[/COLOR]', 'collections&url=smokeyandthebandit', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Speed[/COLOR] [COLOR ] (1994-1997)[/COLOR]', 'collections&url=speed', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Spider-Man[/COLOR] [COLOR ] (2002-2017)[/COLOR]', 'collections&url=spiderman', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Stakeout[/COLOR] [COLOR ] (1987-1993)[/COLOR]', 'collections&url=stakeout', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Star Trek[/COLOR] [COLOR ] (1979-2016)[/COLOR]', 'collections&url=startrek', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Star Wars[/COLOR] [COLOR ] (1977-2015)[/COLOR]', 'collections&url=starwars', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Superman[/COLOR] [COLOR ] (1978-2016)[/COLOR]', 'collections&url=superman', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Sting[/COLOR] [COLOR ] (1973-1983)[/COLOR]', 'collections&url=thesting', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Taken[/COLOR] [COLOR ] (2008-2014)[/COLOR]', 'collections&url=taken', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Taxi[/COLOR] [COLOR ] (1998-2007)[/COLOR]', 'collections&url=taxi', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Ted[/COLOR] [COLOR ] (2012-2015)[/COLOR]', 'collections&url=ted', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Teen Wolf[/COLOR] [COLOR ] (1985-1987)[/COLOR]', 'collections&url=teenwolf', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Terminator[/COLOR] [COLOR ] (1984-2015)[/COLOR]', 'collections&url=terminator', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Terms of Endearment[/COLOR] [COLOR ] (1983-1996)[/COLOR]', 'collections&url=termsofendearment', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Texas Chainsaw Massacre[/COLOR] [COLOR ] (1974-2013)[/COLOR]', 'collections&url=texaschainsawmassacre', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]The Thing[/COLOR] [COLOR ] (1982-2011)[/COLOR]', 'collections&url=thething', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Thomas Crown Affair[/COLOR] [COLOR ] (1968-1999)[/COLOR]', 'collections&url=thomascrownaffair', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Transporter[/COLOR] [COLOR ] (2002-2015)[/COLOR]', 'collections&url=transporter', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Under Siege[/COLOR] [COLOR ] (1992-1995)[/COLOR]', 'collections&url=undersiege', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Universal Soldier[/COLOR] [COLOR ] (1992-2012)[/COLOR]', 'collections&url=universalsoldier', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Wall Street[/COLOR] [COLOR ] (1987-2010)[/COLOR]', 'collections&url=wallstreet', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Waynes World[/COLOR] [COLOR ] (1992-1993)[/COLOR]', 'collections&url=waynesworld', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Weekend at Bernies[/COLOR] [COLOR ] (1989-1993)[/COLOR]', 'collections&url=weekendatbernies', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Whole Nine Yards[/COLOR] [COLOR ] (2000-2004)[/COLOR]', 'collections&url=wholenineyards', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]X-Files[/COLOR] [COLOR ] (1998-2008)[/COLOR]', 'collections&url=xfiles', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]X-Men[/COLOR] [COLOR ] (2000-2016)[/COLOR]', 'collections&url=xmen', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]xXx[/COLOR] [COLOR ] (2002-2005)[/COLOR]', 'collections&url=xxx', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Young Guns[/COLOR] [COLOR ] (1988-1990)[/COLOR]', 'collections&url=youngguns', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Zoolander[/COLOR] [COLOR ] (2001-2016)[/COLOR]', 'collections&url=zoolander', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('[B][COLOR ] [/COLOR][/B][COLOR ghostwhite]Zorro[/COLOR] [COLOR ] (1998-2005)[/COLOR]', 'collections&url=zorro', 'tmdb.png', 'DefaultRecentlyAddedMovies.png')
	self.endDirectory()
		







##########################################################################################################
    def addDirectoryItem(self, name, query, thumb, icon, queue=False, isAction=True, isFolder=True):     #
        try: name = control.lang(name).encode('utf-8')							 #
        except: pass											 #
        url = '%s?action=%s' % (sysaddon, query) if isAction == True else query				 #
        thumb = os.path.join(artPath, thumb) if not artPath == None else icon				 #
        cm = []												 #
        if queue == True: cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))		 #
        item = control.item(label=name)									 #
        item.addContextMenuItems(cm)									 #
        item.setArt({'icon': thumb, 'thumb': thumb})							 #
        if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)			 #
        control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)			 #
    def endDirectory(self):										 #
        control.directory(syshandle, cacheToDisc=True)							 #
##########################################################################################################

