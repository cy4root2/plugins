elif action == 'liptonScraperChoice':
    from resources.lib.modules import control
    control.liptonScraperChoice()
