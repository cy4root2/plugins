# -*- coding: utf-8 -*-

import urlparse

from liptonscrapers import sources_liptonscrapers
from liptonscrapers.modules import control

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?', '')))
action = params.get('action')
mode = params.get('mode')
query = params.get('query')


def ScraperChoice():
    from liptonscrapers import providerSources
    sourceList = sorted(providerSources())
    control.idle()
    select = control.selectDialog([i for i in sourceList])
    if select == -1: return
    module_choice = sourceList[select]
    control.setSetting('module.provider', module_choice)
    control.openSettings('0.1')

def clearSettings():
    if not control.yesnoDialog('Are You Sure?', 'Lipton Module will Clear Your Settings File.', ''):
        return control.openSettings('5.4')
    import os
    addon_data = control.dataPath
    files = control.listDir(addon_data)[1]
    for file in files:
        if file == 'settings.xml':
            settings_file = os.path.join(addon_data, file)
            break
        else: pass
    new_settings_file = control.openFile(settings_file, 'w')
    content = '<settings version="2">\n</settings>'
    new_settings_file.write(content)
    new_settings_file.close
    control.infoDialog('Lipton Scrapers Settings Cleared')
    control.openSettings('5.4')



if action == "LiptonscrapersSettings":
    control.openSettings('0.0', 'script.module.liptonscrapers')

elif mode == "LiptonscrapersSettings":
    control.openSettings('0.0', 'script.module.liptonscrapers')


elif action == "ScraperChoice":
    ScraperChoice()

elif mode == 'activateExternalscrapers':
    from liptonscrapers.modules.external_import import ExternalImporter
    ExternalImporter().importExternal()
    
elif mode == 'removeExternalscrapers':
    from liptonscrapers.modules.external_import import ExternalImporter
    ExternalImporter().removeExternal()

elif mode == 'clearProviderCache':
    from liptonscrapers import deleteProviderCache
    action = deleteProviderCache()
    if action == 'success': control.infoDialog('Lipton Module Results Cleared')
    elif action == 'failure': control.infoDialog('Error Clearing Results Cache')
    control.openSettings('5.1')

elif mode == 'clearSettings':
    clearSettings()


elif action == "toggleAll":
    sourcelist = []
    sourceList = sources_liptonscrapers.all_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.liptonscrapers")


elif action == "toggleAllHosters":
    sourcelist = []
    sourceList = sources_liptonscrapers.hoster_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Hoster providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.liptonscrapers")


elif action == "toggleAllForeign":
    sourcelist = []
    sourceList = sources_liptonscrapers.all_foreign_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Foregin providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.liptonscrapers")


elif action == "toggleAllSpanish":
    sourcelist = []
    sourceList = sources_liptonscrapers.spanish_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Spanish providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.liptonscrapers")


elif action == "toggleAllGerman":
    sourcelist = []
    sourceList = sources_liptonscrapers.german_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All German providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.liptonscrapers")


elif action == "toggleAllGreek":
    sourcelist = []
    sourceList = sources_liptonscrapers.greek_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Greek providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.liptonscrapers")


elif action == "toggleAllPolish":
    sourcelist = []
    sourceList = sources_liptonscrapers.polish_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Polish providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.liptonscrapers")


elif action == "toggleAllPaid":
    sourcelist = []
    sourceList = sources_liptonscrapers.all_paid_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Paid providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.liptonscrapers")


elif action == "toggleAllDebrid":
    sourcelist = []
    sourceList = sources_liptonscrapers.debrid_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Debrid providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.liptonscrapers")


elif action == "toggleAllTorrent":
    sourcelist = []
    sourceList = sources_liptonscrapers.torrent_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Torrent providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.liptonscrapers")

if action == "Defaults":
    sourceList = ['1putlocker', '123movieshubz', 'animetoon', 'azmovie', 'bnwmovies',
                  'cartoonhd', 'cmovieshd', 'coolmoviezone', 'deepmovie', 'divxcrawler', 'extramovies', 'fmoviesio',
                  'freefmovies',
                  'gomoviesink', 'gowatchseries', 'hdmto', 'hdpopcorneu', 'iwaatch', 'iwannawatch',
                  'library', 'movie4kis', 'mycouchtuner', 'myhdpopcorn', 'onlineseries', 'primewire',
                  'projectfreetv', 'putlockerfree', 'putlockeronl', 'seehd', 'series9', 'seriesonline', 'sezonlukdizi',
                  'sharemovies', 'solarmoviefree', 'streamdreams', 'swatchseries', 'timewatch', 'toonget',
                  'tvbox', 'watchepisodes', 'watchserieshd', 'wnmnt', 'xwatchseries', 'yesmoviesgg',
                  '2ddl', '300mbdownload', '300mbfilms', 'ddlspot', 'directdl', 'ganool',
                  'maxrls', 'moviesleak', 'mvrls', 'myvideolink', 'rapidmoviez', 'rlsbb', 'sceneddl', 'scenerls',
                  'scenerlscom', 'ultrahd',
                  'warezmovies', '1337x', 'btdb', 'btscene', 'digbt', 'doublr', 'eztv', 'glodls', 'kickass2',
                  'limetorrents',
                  'magnetdl', 'mkvcage', 'piratebay', 'torrentapi', 'torrentdownloads', 'yify',
                  'yifyddl',
                  'ytsam', 'zoogle']
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    control.openSettings(query, "script.module.liptonscrapers")
