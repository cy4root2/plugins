These files are needed to import lipton scrapers into an addon



https://en.wikipedia.org/wiki/GNU_General_Public_License





@Cy4Root

https://cy4root.github.io/
