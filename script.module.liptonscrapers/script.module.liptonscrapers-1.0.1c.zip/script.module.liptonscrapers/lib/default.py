# -*- coding: utf-8 -*-

import urlparse
from liptonscrapers.modules import control
from liptonscrapers import providerSources, providerNames

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?', '')))
mode = params.get('mode')

def ScraperChoice():
    from liptonscrapers import providerSources
    sourceList = sorted(providerSources())
    control.idle()
    select = control.selectDialog([i for i in sourceList])
    if select == -1: return
    module_choice = sourceList[select]
    control.setSetting('module.provider', module_choice)
    control.openSettings('0.1')

def ToggleProviderAll(enable):
    from liptonscrapers import providerNames
    sourceList = providerNames()
    (setting, open_id) = ('true', '0.3') if enable else ('false', '0.2')
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, setting)
    control.openSettings(open_id)

def toggleAll(setting, open_id=None, sourceList=None):
    from liptonscrapers import getAllHosters
    sourceList = getAllHosters() if not sourceList else sourceList
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, setting)
    control.openSettings(open_id)

#####################################################################################
#  <<<<----Module scrapers settings>>>

if mode == "liptonscrapersettings":
    control.openSettings('0.0')

if mode == "LiptonSettings":
    control.openSettings('0.0', 'script.module.liptonscrapers')

elif mode == "ModuleChoice":
    ModuleChoice()

if mode == "ScraperChoice":
    ScraperChoice()

elif mode == "enableDisableScrapers":
    enableDisableScrapers(params['folder'], params['open_id'])
    
elif mode == 'activateExternalscrapers':
    from liptonscrapers.modules.external_import import ExternalImporter
    ExternalImporter().importExternal()
    
elif mode == 'removeExternalscrapers':
    from liptonscrapers.modules.external_import import ExternalImporter
    ExternalImporter().removeExternal()

####################################################################################



if mode == "ToggleProviderAll":
    ToggleProviderAll(False if params['action'] == "DisableModuleAll" else True)

if mode == "toggleAll":
    open_id = params['open_id'] if 'open_id' in params else '0.0'
    sourcelist = params['sourcelist'] if 'sourcelist' in params else None
    toggleAll(params['setting'], open_id, sourceList=sourcelist)

if mode == "toggleAllDebrid":
    sourcelist = ['0day', '2ddl', '300mbdownload', '300mbfilms', 'bestmoviez', 'ddlspot', 'ddlvalley',
            'directdl', 'maxrls', 'moviesleak', 'mvrls', 'rlsb', 'rlsbb', 'sceneddl', 'scenerls', 'tvdownload',
            'ultrahdindir', 'warezmovies','0day','2ddl','directdl','invictus','myvideolink',
    'playmovies','scenerls','ultrahdindir','wrzcraft','iwantmyshow','moviesleak']
    toggleAll(params['setting'], params['open_id'], sourcelist)

if mode == "toggleAllDirect":
    sourcelist = ['d1dldrm','dl2dlb3d','dl3dlb3d','dl4dlb3d','dl4lavinmovie', 'dl3f2m', 'dl5dlb3d', 'dl5f2m', 'dl6dlb3d', 'dl6f2m', 'dl7dlb3d', 'dl7f2m', 'dl7lavinmovie',
	     'dl8lavinmovie', 'dl8dlb3d', 'dl12dlb3d', 'dldlb3d', 'dlmeliupload', 'dlmyfilm', 'dlsrvdl', 'pz10028', 'pz10093', 's1dlserver', 
	     's1tinydl', 's2dlserver', 's19bitdl', 'stgpz10139']
    toggleAll(params['setting'], params['open_id'], sourcelist)

if mode == "toggleAllSpar":
    sourcelist = ['0123putlocker','123movieshubz','4anime','animefreak','animego', 'animepark', 'animeshow', 'animetoon', 'cartoonextra', 'cartoontab', 'filmv', 'fmovies', 'ganoolrip',
	     'getmywatchseries', 'gogoanime', 'gogoanime1', 'gogoanimestv', 'gomoviesonl', 'goprojectfreetv', 'hackimdb', 'hdmo', 'megashare9', 'movies123', 
	     'mymoviesonline', 'myprojectfreetv', 'myputlockers', 'newepisodes', 'nitermovies','pokemonfire', 'primewire', 'putlockered', 'putlockeronl', 'toonget', 'toonova', 'watch32hd', 'watchseriessto', 'wsunblock',
	     'zmovies']
    toggleAll(params['setting'], params['open_id'], sourcelist)

if mode == "toggleAllGerman":
    sourcelist = ['gamatotv','liomenoi','tainiesonline','tainiomania','xrysoi']
    toggleAll(params['setting'], params['open_id'], sourcelist)

if mode == "toggleAllPolish":
    sourcelist = ['alltube','boxfilm','cdahd','cdax','ekinomaniak','ekinotv','filiser',
    'filmwebbooster','iitv','movieneo','openkatalog','paczamy','segos','szukajkatv','trt']
    toggleAll(params['setting'], params['open_id'], sourcelist)

if mode == "toggleAllSpanish":
    sourcelist = ['megapelistv','peliculasdk','pelisplustv','pepecine','seriespapaya']
    toggleAll(params['setting'], params['open_id'], sourcelist)

if mode == "toggleAllForeign":
    sourcelist = ['cinemay', 'dadyflix', 'dpstreaming', 'fullmoviz', 'fullstream', 'skstream', 'streamingseries',
	     'animebase', 'animeloads', 'bs', 'cine', 'ddl', 'filmpalast', 'foxx', 'hdfilme', 'hdstreams', 'horrorkino', 
	     'iload', 'kinow', 'kinox', 'movie2k-ag', 'movie4k', 'moviesever', 'movietown', 'netzkino', 'proxer', 'serienstream',
	     'seriesever', 'stream-to', 'streamdream', 'streamit', 'video4k', 'view4u', 'view4u2', 'gamatotv', 'tainiomania',
	     'tainiesonline', 'xrysoi', 'liomenoi', 'dramabus', 'iheartdrama', 'ikshow', 'myasiantv', 'alltube', 'alltube3d',
	     'boxfilm', 'cdahd', 'cdapl', 'cdax', 'ekinomaniak', 'ekinotv', 'filiser', 'filman', 'filmbit', 'filmdom',
             'filmosy', 'filmowakrainatv', 'filmwebbooster', 'filmy321', 'horrortube', 'iitvx', 'kinonet', 'movieneo',
             'naszekino', 'serialeco', 'szukajkatv', 'exfs', 'filmix', 'newkino', 'pelisplustv', 'pepecine', 'seriespapaya',
             'portalciyiz', 'sezonlukdizi'
    ]
    toggleAll(params['setting'], params['open_id'], sourcelist)

if mode == "toggleAllTorrent":
    sourcelist = ['bitlord','torrentapi','yify','piratebay','eztv','zoogle','glodls','limetorrents','torrentdownloads','111ys', '1337x', 'btscene', 'doublr', 'eztv', 'glodls', 'kickass2', 'limetorr', 'magnetdl',
            'mkvcage', 'piratebay', 'skytorrents', 'torrapi', 'torrdown', 'torrentquest', 'xpause', 'yifyddl',
            'ytsam', 'zoogle']
    toggleAll(params['setting'], params['open_id'], sourcelist)

if mode == "Defaults":
    sourcelist = ['123123movies', '1movietv', '1putlocker', '5movies', 'allucxyz', 'bnwmovies',
            'cartoonhd', 'cartoonhdto', 'cartoonwire', 'cmovies', 'cmovieshd', 'cmovieshdbz', 'cooltvseries',
            'deepmovie', 'extramovies', 'ffilms', 'filmxy', 'flenixonline', 'flixgo', 'fmoviesag', 'fmoviesio',
            'ganool123', 'geektv', 'gomo', 'gostream123', 'gowatchseries', 'hdbest', 'hdmto', 'hdpopcorns',
            'hubmovie', 'iwannawatch', 'mkvhub', 'movie4kis', 'moviescouch', 'mycoolmoviezone',
            'mycouchtuner', 'myhdpopcorn', 'mymovie4k', 'myswatchseri', 'mywatchep4', 'mywatchepseries',
            'putlockerfree', 'putlockersonline', 'putlockersplus', 'rarefilmm', 'seehd', 'series9', 'seriesfree',
            'seriesonline', 'solarmoviefree', 'telepisodes', 'timewatch', 'tvbox', 'tvmovieflix', 'watchseries',
            'watchserieshd', 'watchseriessi', 'yesmoviesgg']
    toggleAll(params['setting'], params['open_id'], sourcelist)
