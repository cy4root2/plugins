######################################
# Externe Lipton Builder intructions #
######################################



Main.py  

elif action == 'liptonScraperChoice':
    from resources.lib.modules import control
    control.liptonScraperChoice()


###################################################


Settings.py


<category label="32345">
        <setting label="Module Settings" type="lsep" />
        <setting type="sep" />
        <setting type="lsep" label="Choose From LiptonScrapers(Default) or BuiltProviders" />
        <setting id="module.provider" type="labelenum" label="Choose Module Provider Source" default="LiptonScrapers" values="LiptonScrapers|BuiltProviders" />
        <setting id="open.settings" type="action" label="Open LiptonScrapers Settings" option="close" action="RunPlugin(plugin://script.module.liptonscrapers/?mode=LiptonScraperSettings)" />
        <setting id="open.Settings.CacheProviders" type="action" label="Clear Providers Cache" option="close" action="RunPlugin(plugin://plugin.video.chucky/?action=clearAllCache)" /> 
        <setting type="sep" />
        <setting label="Built.Providers" type="lsep" />
        <setting id="builtin.providers.enableall" type="action" label="Enable all BuiltProviders" option="close" action="RunPlugin(plugin://plugin.video.chucky/?action=enableAll)" />
        <setting id="builtin.providers.disableall" type="action" label="Disable all BuiltProviders" option="close" action="RunPlugin(plugin://plugin.video.chucky/?action=disableAll)" />
        <setting type="sep" />  
        <setting id="scrapers.timeout.1" type="slider" label="32312" default="15" range="10,60" option="int" />    
        <setting id="provider.videoscraper" type="bool" label="provider.videoscraper(127.0.0.1:16735)" default="false" />        
        <setting type="sep" />
    </category>  

##########################################################################

Modules >  sources.py


    def getConstants(self):
        self.itemProperty = 'plugin.video.chucky.container.items'
        self.metaProperty = 'plugin.video.chucky.container.meta'

 	#from resources.lib.sources import sources
	#self.sourceDict = sources()    
        scraperSetting = control.setting('module.provider') # Liptonscrapers

        try:
            if xbmc.getCondVisibility('System.HasAddon(%s)' % 'script.module.liptonscrapers') and not scraperSetting == 'BuiltProviders':
                from liptonscrapers import sources
                self.sourceDict = sources()
                scrapers = [i[0] for i in self.sourceDict]
                try:
                    self.module_name =     'Exodus' if scrapers[0].split('_')[1].lower() == 'exodus' else \
                                           'Scrubsv2' if scrapers[0].split('_')[1].lower() == 'scrubsv2' else \
                                           'numbers' if scrapers[0].split('_')[1].lower() == 'numbers' else 'BuiltProviders'
                except: self.module_name = 'Lipton'
            else:
                from resources.lib.sources import sources
                self.sourceDict = sources()
                self.module_name = 'Build'
                control.setSetting('module.provider', 'BuiltProviders')
        except: return

        try:
            self.hostDict = resolveurl.relevant_resolvers(order_matters=True)
            self.hostDict = [i.domains for i in self.hostDict if not '*' in i.domains]
            self.hostDict = [i.lower() for i in reduce(lambda x, y: x+y, self.hostDict)]
            self.hostDict = [x for y,x in enumerate(self.hostDict) if x not in self.hostDict[:y]]
        except:
            self.hostDict = []

        self.hostprDict = ['1fichier.com', 'oboom.com', 'rapidgator.net', 'rg.to', 'uploaded.net', 'uploaded.to', 'ul.to', 'filefactory.com', 'nitroflare.com', 'turbobit.net', 'uploadrocket.net']

        self.hostcapDict = ['hugefiles.net', 'kingfiles.net', 'openload.io', 'openload.co', 'oload.tv', 'thevideo.me', 'vidup.me', 'streamin.to', 'torba.se']

        self.hosthqDict = ['gvideo', 'google.com', 'openload.io', 'openload.co', 'oload.tv', 'thevideo.me', 'rapidvideo.com', 'raptu.com', 'filez.tv', 'uptobox.com', 'uptobox.com', 'uptostream.com', 'xvidstage.com', 'streamango.com']

        self.hostblockDict = []
