<category label="32345">
        <setting label="Module Settings" type="lsep" />
        <setting type="sep" />
        <setting type="lsep" label="Choose From LiptonScrapers(Default) or BuiltProviders" />
        <setting id="module.provider" type="labelenum" label="Choose Module Provider Source" default="LiptonScrapers" values="LiptonScrapers|BuiltProviders" />
        <setting id="open.settings" type="action" label="Open LiptonScrapers Settings" option="close" action="RunPlugin(plugin://script.module.liptonscrapers/?mode=LiptonSettings)" />
        <setting id="open.Settings.CacheProviders" type="action" label="Clear Providers Cache" option="close" action="RunPlugin(plugin://plugin.video.xxxxxx/?action=clearAllCache)" /> 
        <setting type="sep" />
        <setting label="Built.Providers" type="lsep" />
        <setting id="builtin.providers.enableall" type="action" label="Enable all BuiltProviders" option="close" action="RunPlugin(plugin://plugin.video.xxxxxx/?action=enableAll)" />
        <setting id="builtin.providers.disableall" type="action" label="Disable all BuiltProviders" option="close" action="RunPlugin(plugin://plugin.video.xxxxx/?action=disableAll)" />
        <setting type="sep" />  
        <setting id="scrapers.timeout.1" type="slider" label="32312" default="15" range="10,60" option="int" />    
        <setting id="provider.videoscraper" type="bool" label="provider.videoscraper(127.0.0.1:16735)" default="false" />        
        <setting type="sep" />
    </category>
