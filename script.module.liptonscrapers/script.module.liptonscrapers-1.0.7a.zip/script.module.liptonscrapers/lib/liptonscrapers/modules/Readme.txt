######################################
# Externe Lipton Builder intructions #
######################################



Main.py  

elif action == 'alterSources':
    from resources.lib.modules import sources
    sources.sources().alterSources(url, meta)

elif action == 'liptonScraperChoice':
    from resources.lib.modules import control
    control.liptonScraperChoice()

elif action == 'installOpenscrapers':
    from resources.lib.modules import control
    control.installAddon('script.module.openscrapers')
    control.sleep(200)
    control.refresh()

elif action == 'openscrapersettings':
    from resources.lib.modules import control
    control.openSettings('0.0', 'script.module.openscrapers')


###################################################


Settings.py

    <category label="Providers"> # Cy4Root
        <setting id="open.settings" type="action" label="Provider Settings" option="close" action="RunPlugin(plugin://script.module.liptonscrapers/?mode=LiptonScraperSettings)" />
        <setting id="scrapers.timeout.1" type="slider" label="32312" default="20" range="10,60" option="int" /> 
        <setting type="sep" />
        <setting id="remove.dups" type="bool" label="32090" default="true" />
        <setting id="debrid.only" type="bool" label="32685" default="false" />      
        <setting type="sep" />
        <setting id="open.Settings.CacheProviders" type="action" label="Clear Providers Cache" option="close" action="RunPlugin(plugin://plugin.video.laplaza/?action=clearAllCache)" /> 
        <setting type="lsep" label="Account Settings" />    
        <setting id="RealDebridResolver_auth" type="action" label="RealDebrid Authorize" action="RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)"/>
        <setting id="AllDebridResolver_auth" type="action" label="AllDebrid Authorize" action="RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)"/>
        <setting id="PremiumizeMeResolver_auth" type="action" label="PremiumizeMe Authorize" action="RunPlugin(plugin://script.module.resolveurl/?mode=auth_pm)"/>
        <setting type="sep" />
        <setting id="trakt.auth" type="action" label="Trakt Authorize" option="close" action="RunPlugin(plugin://plugin.video.laplaza/?action=authTrakt)" />
        <setting type="sep" />  

        <setting type="sep" />
    </category>   

 <category label="Externe Scrapers"> # Cy4Root
        <setting id="module.provider" type="select" label="32084" values="[B][COLOR gold]Lipton-Module[/COLOR][/B]|Open Scrapers" default="[B][COLOR gold]Lipton-Module[/COLOR][/B]" visible="System.HasAddon(script.module.openscrapers)" />
        <setting id="module.provider.alt" type="select" label="32084" values="Lipton-Module|Open Scrapers" default="Lipton-Module" visible="!System.HasAddon(script.module.openscrapers)" />
        <setting id="open.settings.openscrapers" type="action" label="Open Scrapers Settings (optional)" option="close" action="RunPlugin(plugin://script.module.openscrapers/?mode=OpenscrapersSettings)" />
        <setting type="sep" />
        <setting id="open.Settings.CacheProviders" type="action" label="Clear Providers Cache" option="close" action="RunPlugin(plugin://plugin.video.laplaza/?action=clearAllCache)" /> 
        <setting type="sep" />
    </category> 

##########################################################################

Modules >  sources.py

# Funtion for dupicate links
-----------------------------

def sourcesFilter(self):
        provider = control.setting('hosts.sort.provider')
        if provider == '': provider = 'false'

        debrid_only = control.setting('debrid.only')
        if debrid_only == '': debrid_only = 'false'

        quality = control.setting('hosts.quality')
        if quality == '': quality = '0'

        captcha = control.setting('hosts.captcha')
        if captcha == '': captcha = 'true'

        HEVC = control.setting('HEVC')

        random.shuffle(self.sources)

        if provider == 'true':
            self.sources = sorted(self.sources, key=lambda k: k['provider'])

        if not HEVC == 'true':
            self.sources = [i for i in self.sources if not any(value in str(i['url']).lower() for value in ['hevc', 'h265', 'h.265', 'x265', 'x.265'])]


        local = [i for i in self.sources if 'local' in i and i['local'] == True]
        for i in local: i.update({'language': self._getPrimaryLang() or 'en'})
        self.sources = [i for i in self.sources if not i in local]



        ''' Filter-out duplicate links'''
        try:
            if control.setting('remove.dups') == 'true':
                stotal = len(self.sources)
                self.sources = list(self.uniqueSourcesGen(self.sources))
                dupes = int(stotal - len(self.sources))
                control.infoDialog(control.lang(32089).encode('utf-8').format(dupes), sound=True, icon='INFO')
            else:
                self.sources
        except:
            import traceback
            failure = traceback.format_exc()
            log_utils.log('DUP - Exception: ' + str(failure))
            control.infoDialog('Dupes filter failed', sound=True, icon='INFO')
            self.sources
        '''END'''

        filter = []


        for i in self.sources:
            if 'checkquality' in i and i['checkquality'] == True:
                if not i['source'].lower() in self.hosthqDict and i['quality'] not in ['SD', 'SCR', 'CAM']: i.update({'quality': 'SD'})
        
        local = [i for i in self.sources if 'local' in i and i['local'] == True]
        for i in local: i.update({'language': self._getPrimaryLang() or 'en'})
        self.sources = [i for i in self.sources if not i in local]

        filter = []
        filter += [i for i in self.sources if i['direct'] == True]
        filter += [i for i in self.sources if i['direct'] == False]
        self.sources = filter

        filter = []

        for d in debrid.debrid_resolvers:
            valid_hoster = set([i['source'] for i in self.sources])
            valid_hoster = [i for i in valid_hoster if d.valid_url('', i)]
            filter += [dict(i.items() + [('debrid', d.name)]) for i in self.sources if i['source'] in valid_hoster]
        if debrid_only == 'false' or  debrid.status() == False:
            filter += [i for i in self.sources if not i['source'].lower() in self.hostprDict and i['debridonly'] == False]

        self.sources = filter
      
        for i in range(len(self.sources)):
            q = self.sources[i]['quality']            
            if q == 'HD': self.sources[i].update({'quality': '720p'})

        filter = []
        filter += local

        if quality in ['0']: filter += [i for i in self.sources if i['quality'] == '4K' and 'debrid' in i]
        if quality in ['0']: filter += [i for i in self.sources if i['quality'] == '4K' and not 'debrid' in i and 'memberonly' in i]
        if quality in ['0']: filter += [i for i in self.sources if i['quality'] == '4K' and not 'debrid' in i and not 'memberonly' in i]

        if quality in ['0', '1']: filter += [i for i in self.sources if i['quality'] == '1440p' and 'debrid' in i]
        if quality in ['0', '1']: filter += [i for i in self.sources if i['quality'] == '1440p' and not 'debrid' in i and 'memberonly' in i]
        if quality in ['0', '1']: filter += [i for i in self.sources if i['quality'] == '1440p' and not 'debrid' in i and not 'memberonly' in i]

        if quality in ['0', '1', '2']: filter += [i for i in self.sources if i['quality'] == '1080p' and 'debrid' in i]
        if quality in ['0', '1', '2']: filter += [i for i in self.sources if i['quality'] == '1080p' and not 'debrid' in i and 'memberonly' in i]
        if quality in ['0', '1', '2']: filter += [i for i in self.sources if i['quality'] == '1080p' and not 'debrid' in i and not 'memberonly' in i]

        if quality in ['0', '1', '2', '3']: filter += [i for i in self.sources if i['quality'] == '720p' and 'debrid' in i]
        if quality in ['0', '1', '2', '3']: filter += [i for i in self.sources if i['quality'] == '720p' and not 'debrid' in i and 'memberonly' in i]
        if quality in ['0', '1', '2', '3']: filter += [i for i in self.sources if i['quality'] == '720p' and not 'debrid' in i and not 'memberonly' in i]

        filter += [i for i in self.sources if i['quality'] in ['SD', 'SCR', 'CAM']]
        self.sources = filter

        if not captcha == 'true':
            filter = [i for i in self.sources if i['source'].lower() in self.hostcapDict and not 'debrid' in i]
            self.sources = [i for i in self.sources if not i in filter]

        filter = [i for i in self.sources if i['source'].lower() in self.hostblockDict and not 'debrid' in i]
        self.sources = [i for i in self.sources if not i in filter]
        
        multi = [i['language'] for i in self.sources]
        multi = [x for y,x in enumerate(multi) if x not in multi[:y]]
        multi = True if len(multi) > 1 else False

        if multi == True:
            self.sources = [i for i in self.sources if not i['language'] == 'en'] + [i for i in self.sources if i['language'] == 'en']
        
        self.sources = self.sources[:2000]

        extra_info = control.setting('sources.extrainfo')
        prem_identify = control.setting('prem.identify')
        if prem_identify == '': prem_identify = 'blue'
        prem_identify = self.getPremColor(prem_identify)        
        
        for i in range(len(self.sources)):
                       
            if extra_info == 'true': t = source_utils.getFileType(self.sources[i]['url'])
            else: t = None
            
            u = self.sources[i]['url']

            p = self.sources[i]['provider']

            q = self.sources[i]['quality']

            s = self.sources[i]['source']
            
            s = s.rsplit('.', 1)[0]

            l = self.sources[i]['language']

            try: f = (' | '.join(['[I]%s [/I]' % info.strip() for info in self.sources[i]['info'].split('|')]))
            except: f = ''

            try: d = self.sources[i]['debrid']
            except: d = self.sources[i]['debrid'] = ''

            if d.lower() == 'real-debrid': d = 'RD'

            if not d == '': label = '%02d | [B]%s | %s[/B] | ' % (int(i+1), d, p)
            else: label = '%02d | [B]%s[/B] | ' % (int(i+1), p)

            if multi == True and not l == 'en': label += '[B]%s[/B] | ' % l

            if t:
                if q in ['4K', '1440p', '1080p', '720p']: label += '%s | [B][I]%s [/I][/B] | [I]%s[/I] | %s' % (s, q, t, f)
                elif q == 'SD': label += '%s | %s | [I]%s[/I]' % (s, f, t)
                else: label += '%s | %s | [I]%s [/I] | [I]%s[/I]' % (s, f, q, t)
            else:
                if q in ['4K', '1440p', '1080p', '720p']: label += '%s | [B][I]%s [/I][/B] | %s' % (s, q, f)
                elif q == 'SD': label += '%s | %s' % (s, f)
                else: label += '%s | %s | [I]%s [/I]' % (s, f, q)
            label = label.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
            label = re.sub('\[I\]\s+\[/I\]', ' ', label)
            label = re.sub('\|\s+\|', '|', label)
            label = re.sub('\|(?:\s+|)$', '', label)
            
            if d: 
                if not prem_identify == 'nocolor':
                    self.sources[i]['label'] = ('[COLOR %s]' % (prem_identify)) + label.upper() + '[/COLOR]'
                else: self.sources[i]['label'] = label.upper()
            else: self.sources[i]['label'] = label.upper()

        try: 
            if not HEVC == 'true': self.sources = [i for i in self.sources if not 'HEVC' in i['label']]
        except: pass
            
        self.sources = [i for i in self.sources if 'label' in i]
    
        return self.sources


#  make the multi sources working!!!
----------------------------------

 def getConstants(self):
        self.itemProperty = 'plugin.video.laplaza.container.items'

        self.metaProperty = 'plugin.video.laplaza.container.meta'

        if control.condVisibility('System.HasAddon(script.module.openscrapers)'):
            scraperSetting = control.setting('module.provider')
        else:
            scraperSetting = control.setting('module.provider.alt')

        from resources.lib.sources import sources
        sourceDir2 = sources()
        from liptonscrapers import sources
        sourceDir3 = sources()
        try:
            from openscrapers import sources
            sourceDir1 = sources()
        except:
            pass

        try: # more options but no needed
            if scraperSetting == 'Lipton Scrapers':
                self.sourceDict = sourceDir3
                self.module_name = 'LiptonScrapers (' + str(control.addon('script.module.liptonscrapers').getSetting('module.provider')) + ' module):'
            elif scraperSetting == 'Open Scrapers':
                self.sourceDict = sourceDir1
                self.module_name = 'OpenScrapers:'
            elif scraperSetting == 'Built-in':
                self.sourceDict = sourceDir2
                self.module_name = 'Built-in providers:'
            elif scraperSetting == 'Lipton + Built-in':
                self.sourceDict = sourceDir2 + sourceDir3
                self.module_name = 'Built-in + Lipton (' + str(control.addon('script.module.liptonscrapers').getSetting('module.provider')) + ' module):'
            elif scraperSetting == 'Open + Built-in':
                self.sourceDict = sourceDir1 + sourceDir2
                self.module_name = 'Built-in + OpenScrapers:'
            else:
                self.sourceDict = sourceDir3
                self.module_name = 'LiptonScrapers (' + str(control.addon('script.module.liptonscrapers').getSetting('module.provider')) + ' module):'
                control.setSetting('module.provider', 'Lipton Scrapers')
        except: return

        try:
            self.hostDict = resolveurl.relevant_resolvers(order_matters=True)
            self.hostDict = [i.domains for i in self.hostDict if not '*' in i.domains]
            self.hostDict = [i.lower() for i in reduce(lambda x, y: x+y, self.hostDict)]
            self.hostDict = [x for y,x in enumerate(self.hostDict) if x not in self.hostDict[:y]]
        except:
            self.hostDict = []

        self.hostprDict = ['1fichier.com', 'oboom.com', 'rapidgator.net', 'rg.to', 'uploaded.net', 'uploaded.to', 'uploadgig.com', 'ul.to', 'filefactory.com', 'nitroflare.com', 'turbobit.net', 'uploadrocket.net', 'multiup.org']

        self.hostcapDict = ['openload.io', 'openload.co', 'oload.tv', 'oload.stream', 'oload.win', 'oload.download', 'oload.info', 'oload.icu', 'oload.fun', 'oload.life', 'openload.pw',
                            'vev.io', 'vidup.me', 'vidup.tv', 'vshare.io', 'vshare.eu', 'flashx.tv', 'flashx.to', 'flashx.sx', 'flashx.bz', 'flashx.cc',
                            'hugefiles.net', 'thevideo.me', 'streamin.to']

        self.hosthqDict = ['gvideo', 'google.com', 'openload.io', 'openload.co', 'oload.tv', 'thevideo.me', 'rapidvideo.com', 'raptu.com', 'filez.tv', 'uptobox.com', 'uptostream.com',
                           'xvidstage.com', 'streamango.com', 'xstreamcdn.com', 'idtbox.com']

        self.hostblockDict = ['zippyshare.com', 'youtube.com', 'facebook.com', 'twitch.tv']

    def enableAll(self):
        try:
            sourceDict = self.sourceDict
            for i in sourceDict:
                source_setting = 'provider.' + i[0].split('_')[0]
                control.setSetting(source_setting, 'true')
        except: pass
        control.openSettings('3.3')

    def disableAll(self):
        try:
            sourceDict = self.sourceDict
            for i in sourceDict:
                source_setting = 'provider.' + i[0].split('_')[0]
                control.setSetting(source_setting, 'false')
        except: pass
        control.openSettings('3.4')

    def getPremColor(self, n):
        if n == '0': n = 'blue'
        elif n == '1': n = 'red'
        elif n == '2': n = 'yellow'
        elif n == '3': n = 'deeppink'
        elif n == '4': n = 'cyan'
        elif n == '5': n = 'lawngreen'
        elif n == '6': n = 'gold'
        elif n == '7': n = 'magenta'
        elif n == '8': n = 'yellowgreen'
        elif n == '9': n = 'white'
        elif n == '10': n = 'black'
        elif n == '11': n = 'crimson'
        elif n == '12': n = 'goldenrod'
        elif n == '13': n = 'powderblue'
        elif n == '14': n = 'deepskyblue'
        elif n == '15': n = 'springgreen'
        elif n == '16': n = 'darkcyan'
        elif n == '17': n = 'aquamarine'
        elif n == '18': n = 'mediumturquoise'
        elif n == '19': n = 'khaki'
        elif n == '20': n = 'darkorange'
        elif n == '21': n = 'none'
        else: n = 'gold'
        return n





    
