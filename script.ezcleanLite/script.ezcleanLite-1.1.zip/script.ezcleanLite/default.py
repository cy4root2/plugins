# -*- coding: UTF-8 -*-

import os,sys,urllib
from resources.lib.modules import control


AddonID = control.AddonID
AddonTitle = control.AddonTitle
MENU_FANART = control.AddonFanart
MENU_ICON = "DefaultAddonProgram.png"
getSetEnabled = control.getSettingEnabled
Notify = control.Notify
log = control.log


def setView(content, viewType):
    if content:
        control.content(int(sys.argv[1]), content)
    if control.getSetting('auto-view')=='true':
        views = control.getSetting('viewType2')
        if views == '50' and control.getKodiVersion >= 17 and control.skin == 'skin.estuary': views = '55'
        if views == '500' and control.getKodiVersion >= 17 and control.skin == 'skin.estuary': views = '50'
        return control.execute("Container.SetViewMode(%s)" % views)
    else:
        views = control.getCurrentViewId()
        return control.execute("Container.SetViewMode(%s)" % views)


def CreateDir(name, url, action, icon, fanart, description, isFolder=False):
    CustomColor = control.setting('my_ColorChoice')
    if CustomColor == '': CustomColor = 'none'
    if icon == None or icon == '': icon = MENU_ICON
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&action="+str(action)+"&name="+urllib.quote_plus(name)+"&icon="+urllib.quote_plus(icon)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    name = '[COLOR %s][B]%s[/B][/COLOR]' % (CustomColor, name)
    liz=control.item(name, iconImage="DefaultAddonProgram.png", thumbnailImage=icon)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty("Fanart_Image", fanart)
    ok=control.addItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
    return ok


def MAIN_MENU():
    setView('addons', 'views')
    if getSetEnabled('navi.maintenance') == True:
        CreateDir('Maintenance', 'url', 'maintenance', MENU_ICON, MENU_FANART, 'Maintenance Menu.', isFolder=True )
        CreateDir('SpeedTest', 'url', 'speedTest', MENU_ICON, MENU_FANART, 'Run a SpeedTest real quick.' )
        CreateDir('Net Info', 'url', 'netINFO', MENU_ICON, MENU_FANART, 'View Device Net Info.', isFolder=True )
        CreateDir('Freshstart', 'url', 'freshStart', MENU_ICON, MENU_FANART, 'description' )
        CreateDir('forceClose', 'url', 'Force_Close' , MENU_ICON, MENU_FANART, 'description' )     
        CreateDir('Settings', 'url', 'settings', MENU_ICON, MENU_FANART, '%s Settings.' %AddonTitle)


def MAINTENANCE():
    setView('addons', 'views') 
    CreateDir( 'Clear All (Cache, Packages, Thumbnails)', 'url', 'clear_ALL', MENU_ICON, MENU_FANART, 'description' )
    CreateDir( 'Clear Cache', 'url', 'deleteCache', MENU_ICON, MENU_FANART, 'description' )
    CreateDir( 'Clear Thumbnails', 'url', 'clearThumb', MENU_ICON, MENU_FANART, 'description' )
    CreateDir( '[I]Clear Resolvers Cache[/I]', 'url', 'reset_ResolversCache', MENU_ICON, MENU_FANART, 'description' )
    CreateDir( '[I]Clear Empty Folders[/I]', 'url', 'clearEmptyFolders', MENU_ICON, MENU_FANART, 'description' )
    CreateDir( 'Check Sources', 'url', 'checkSources', MENU_ICON, MENU_FANART, 'Check for any Broken Sources.' )
    CreateDir( 'Check Repos', 'url', 'checkRepos', MENU_ICON, MENU_FANART, 'Check for any Broken Repos.' )
    CreateDir( 'Check for Updates (ALL)', 'url', 'forceUpdate', MENU_ICON, MENU_FANART, 'Check for any new Updates.' )
    CreateDir( 'Disable AutoUpdates(Notify but dont install)', 'url', 'disableAutoUpdates', MENU_ICON, MENU_FANART, 'Set AutoUpdates To Notify but not Auto Intsall.' )
    CreateDir( 'Enable Unknown Sources', 'url', 'enableUnknownSources', MENU_ICON, MENU_FANART, 'Enable Unknown Sources.' )


def NETINFO():
    setView('addons', 'views')
    from resources.lib.modules import toolz
    mac, inter_ip, ip, city, state, country, isp = toolz.net_info()
    CreateDir('Mac: [ %s ]' % (mac), '', '', MENU_ICON, MENU_FANART, '' )
    CreateDir('External IP: [ %s ]' % (ip), '', '', MENU_ICON, MENU_FANART, '' )
    CreateDir('City: [ %s ]' % (city), '', '', MENU_ICON, MENU_FANART, '' )
    CreateDir('State: [ %s ]' % (state), '', '', MENU_ICON, MENU_FANART, '' )
    CreateDir('Country: [ %s ]' % (country), '', '', MENU_ICON, MENU_FANART, '' )
    CreateDir('ISP: [ %s ]' % (isp), '', '', MENU_ICON, MENU_FANART, '' )


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
        return param


params = get_params()
url = None
try: url = urllib.unquote_plus(params["url"])
except: pass
action = None
try: action = urllib.unquote_plus(params["action"])
except: pass
name = None
try: name = urllib.unquote_plus(params["name"])
except: pass
icon = None
try: icon = urllib.unquote_plus(params["icon"])
except: pass
fanart = None
try: fanart = urllib.unquote_plus(params["fanart"])
except: pass
description = None
try: description = urllib.unquote_plus(params["description"])
except: pass
mode = None
try: mode = urllib.unquote_plus(params["mode"])
except: pass


if action == None: MAIN_MENU()
elif action == 'maintenance': MAINTENANCE()
elif action == "netINFO": NETINFO()
elif action == "Freshstart": Freshstart()
elif action == 'settings': control.openSettings()


elif action == 'viewTypes':
    from resources.lib.api import viewTypes
    viewTypes.getViewType()



elif action == 'clear_ALL':
    from resources.lib.modules import maintenance
    maintenance.clearCache()
    maintenance.purgePackages()
    maintenance.deleteThumbnails()


elif action == 'deleteCache':
    from resources.lib.modules import clean
    clean.Delete_Cache(url)


elif action == 'deletePackages':
    from resources.lib.modules import clean
    clean.Delete_Packages(url)


elif action == 'clearThumb':
    from resources.lib.modules import clean
    clean.Clear_Thumb()


elif action == 'reset_ResolversCache':
    from resources.lib.modules import toolz
    Notify(AddonTitle, 'Clearing Resolver Cache...')
    toolz.resetResolversCache()


elif action == 'clearEmptyFolders':
    from resources.lib.modules import cleantool
    Notify(AddonTitle, 'Clearing Empty Folders...')
    cleantool.REMOVE_EMPTY_FOLDERS()
    Notify(AddonTitle, 'Done Clearing Empty Folders.')

elif action == 'freshStart':
    from resources.lib.modules import freshstart
    Notify(AddonTitle, 'Wipe your system...')
    freshstart.FRESHSTART()
    Notify(AddonTitle, 'Done')

elif action == 'Force_Close':
    from resources.lib.modules import forceClose
    forceClose.ForceClose()


elif action == 'advancedSettings':
    from resources.lib.index import ezactions
    ezactions.advancedSettingsMenu()


elif action == 'checkSources':
    from resources.lib.modules import utilz
    utilz.Broken_Sources()


elif action == 'checkRepos':
    from resources.lib.modules import utilz
    utilz.Broken_Repos()


elif action == 'forceUpdate':
    from resources.lib.modules import toolz
    toolz.ForceUpdateCheck()


elif action == 'enableAddons':
    from resources.lib.modules import toolz
    toolz.ENABLE_ADDONS()


elif action == 'enableUnknownSources':
    from resources.lib.modules import toolz
    toolz.swapUS()


elif action == 'disableAutoUpdates':
    from resources.lib.modules import toolz
    toolz.AutoUpdateToggle_System()

elif action == 'speedTest':
    from resources.lib.index import speedTest
    result = speedTest.fast_com()
    ok = control.OkDialog("FAST.com", "Result: %s Mbps" % result)


elif action == 'checkCurrentProfile':
    from resources.lib.modules import toolz
    userName = toolz.Current_Profile()
    TestItem = 'Current Profile: %s' % userName
    control.Notify(AddonTitle, TestItem)
control.directory(int(sys.argv[1]))

