# -*- coding: UTF-8 -*-

import re,os,sys,urllib,time,zipfile
import xbmc,xbmcaddon,xbmcgui
from resources.lib.modules import control
from resources.lib.modules import maintenance
from datetime import datetime

AddonID = control.AddonID
AddonTitle = control.AddonTitle
Notify = control.Notify
HOME = control.transPath('special://home/') 
HOMEPATH = control.transPath('special://home/') 
USERDATA = control.transPath(os.path.join('special://home/userdata',''))
USERDATAPATH = os.path.join(HOMEPATH, 'userdata') 
ADDONDATA = os.path.join(USERDATAPATH, 'addon_data', AddonID) 
dialog = control.dialog 
dp = control.dp 

def REMOVE_EMPTY_FOLDERS():
    print"########### Start Removing Empty Folders #########"
    empty_count = 0 
    used_count = 0
    try:
        for curdir, subdirs, files in os.walk(HOME):
            if len(subdirs) == 0 and len(files) == 0: 
                empty_count += 1 
                os.rmdir(curdir) 
                print "successfully removed: "+curdir
            elif len(subdirs) > 0 and len(files) > 0: 
                used_count += 1 
    except: pass

def FRESHSTART(mode='verbose'):
    EXCLUDES = [AddonID, 'backupdir', 'backup.zip', 'script.module.requests', 'script.module.urllib3', 'script.module.chardet', 'script.module.idna', 'script.module.certifi']
    if mode!= 'silent': select = control.yesnoDialog(AddonTitle, 'Are you absolutely certain you want to wipe this install?', '', 'All addons EXCLUDING THIS WIZARD will be completely wiped!', yeslabel='Yes',nolabel='No')
    else: select = 1
    if select == 0: return
    elif select == 1:
        dp.create(AddonTitle, 'Wiping Install', '', 'Please Wait')
        try:
            for root, dirs, files in os.walk(HOME,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try:
                        os.remove(os.path.join(root,name))
                        os.rmdir(os.path.join(root,name))
                    except: pass
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
                    except: pass
        except: pass
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    # RESTOREFAV()
    ENABLE_WIZARD()
    if mode!= 'silent': dialog.ok(AddonTitle, 'Wipe Successful, The interface will now be reset...', '', '')
    # control.execute('Mastermode')
    if mode!= 'silent': control.execute('LoadProfile(Master user)')
    # control.execute('Mastermode')

