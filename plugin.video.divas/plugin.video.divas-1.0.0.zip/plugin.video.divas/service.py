# -*- coding: utf-8 -*-

"""
divas
"""


import threading
from resources.lib.modules import control,log_utils


control.execute('RunPlugin(plugin://%s)' % control.get_plugin_url({'action': 'service'}))


try:
    AddonVersion = control.addon('plugin.video.divas').getAddonInfo('version')
    RepoVersion = control.addon('repository.divas').getAddonInfo('version')
    log_utils.log('################### divas ######################', log_utils.LOGNOTICE)
    log_utils.log('####### CURRENT divas VERSIONS REPORT ##########', log_utils.LOGNOTICE)
    log_utils.log('######### divas PLUGIN VERSION: %s #########' % str(AddonVersion), log_utils.LOGNOTICE)
    log_utils.log('####### divas REPOSITORY VERSION: %s #######' % str(RepoVersion), log_utils.LOGNOTICE)
    log_utils.log('################################################', log_utils.LOGNOTICE)

except:
    log_utils.log('############################# divas ############################', log_utils.LOGNOTICE)
    log_utils.log('################# CURRENT divas VERSIONS REPORT ################', log_utils.LOGNOTICE)
    log_utils.log('# ERROR GETTING divas VERSION - Missing Repo of failed Install #', log_utils.LOGNOTICE)
    log_utils.log('################################################################', log_utils.LOGNOTICE)


def syncTraktLibrary():
    control.execute('RunPlugin(plugin://%s)' % 'plugin.video.divas/?action=tvshowsToLibrarySilent&url=traktcollection')
#    control.execute('RunPlugin(plugin://%s)' % 'plugin.video.divas/?action=syncWatchedTVvshows&url=traktWatchedTVshows')
    control.execute('RunPlugin(plugin://%s)' % 'plugin.video.divas/?action=moviesToLibrarySilent&url=traktcollection')
#    control.execute('RunPlugin(plugin://%s)' % 'plugin.video.divas/?action=synWatchedMovies&url=traktWatchedMovies')


if control.setting('autoTraktOnStart') == 'true':
    syncTraktLibrary()


if int(control.setting('schedTraktTime')) > 0:
    log_utils.log('###############################################################', log_utils.LOGNOTICE)
    log_utils.log('#################### STARTING TRAKT SCHEDULING ################', log_utils.LOGNOTICE)
    log_utils.log('#################### SCHEDULED TIME FRAME '+ control.setting('schedTraktTime')  + ' HOURS ###############', log_utils.LOGNOTICE)
    timeout = 3600 * int(control.setting('schedTraktTime'))
    schedTrakt = threading.Timer(timeout, syncTraktLibrary)
    schedTrakt.start()



