import xbmcaddon
import base64

Decode = base64.decodestring
MainBase = 'https://raw.githubusercontent.com/demon-bit/xml-master/master/lists/custom.xml'
addon = xbmcaddon.Addon('plugin.video.sportzig')
