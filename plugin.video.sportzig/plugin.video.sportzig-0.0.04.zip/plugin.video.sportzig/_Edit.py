import xbmcaddon
import base64

Decode = base64.decodestring
MainBase = base64.b64decode ('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2RlbW9uLWJpdC94bWwtbWFzdGVyL21hc3Rlci9qZW4tbWFzdGVyL3Nwb3J0emlnL21haW4ueG1s')
addon = xbmcaddon.Addon('plugin.video.sportzig')
