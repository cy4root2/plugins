# -*- coding: utf-8 -*-

import urlparse

from cy4rootscrapers import sources_cy4rootscrapers
from cy4rootscrapers.modules import control


params = dict(urlparse.parse_qsl(sys.argv[2].replace('?', '')))
action = params.get('action')
mode = params.get('mode')
query = params.get('query')


def ScraperChoice():
    from cy4rootscrapers import providerSources
    sourceList = sorted(providerSources())
    control.idle()
    select = control.selectDialog([i for i in sourceList])
    if select == -1: return
    module_choice = sourceList[select]
    control.setSetting('module.provider', module_choice)
    control.openSettings('0.1')


if action == "cy4rootscrapers":
    control.openSettings('0.0', 'script.module.cy4rootscrapers')

elif mode == "cy4rootscrapers":
    control.openSettings('0.0', 'script.module.cy4rootscrapers')


elif action == "ScraperChoice":
    ScraperChoice()

sourceList = sources_cy4rootscrapers.all_providers
##########################################################################################

if mode == "toggleAllNormal":
    sourcelist = ['123123movies', '1movietv', '1putlocker', '5movies', 'allucxyz', 'bnwmovies',
            'cartoonhd', 'cartoonhdto', 'cartoonwire', 'cmovies', 'cmovieshd', 'cmovieshdbz', 'cooltvseries',
            'deepmovie', 'extramovies', 'ffilms', 'filmxy', 'flenixonline', 'flixgo', 'fmoviesag', 'fmoviesio',
            'ganool123', 'geektv', 'gomo', 'gostream123', 'gowatchseries', 'hdbest', 'hdmto', 'hdpopcorns',
            'hubmovie', 'iwannawatch', 'mkvhub', 'movie4kis', 'moviescouch', 'mycoolmoviezone',
            'mycouchtuner', 'myhdpopcorn', 'mymovie4k', 'myswatchseri', 'mywatchep4', 'mywatchepseries',
            'putlockerfree', 'putlockersonline', 'putlockersplus', 'rarefilmm', 'seehd', 'series9', 'seriesfree',
            'seriesonline', 'solarmoviefree', 'telepisodes', 'timewatch', 'tvbox', 'tvmovieflix', 'watchseries',
            'watchserieshd', 'watchseriessi', 'yesmoviesgg'
    ]
    toggleAll(params['setting'], params['query'], sourcelist)
if mode == "toggleAllSpares":
    sourcelist = ['0123putlocker', '123movieshubz', '4anime', 'animefreak', 'animego', 'animepark',
            'animeshow', 'animetoon', 'cartoonextra', 'cartoontab', 'filmv', 'fmovies', 'ganoolrip', 'getmywatchseries',
            'gogoanime', 'gogoanime1', 'gogoanimestv', 'gomoviesonl', 'goprojectfreetv', 'hdmo', 'hackimdb',
            'hnmovies', 'megashare9', 'movies123', 'mymoviego', 'mymoviesonline', 'myprojectfreetv', 'myputlockers',
            'newepisodes', 'nitermovies', 'pokemonfire', 'primewire', 'putlockered', 'putlockeronl', 'sharemovies',
            'sezonlukdizi', 'solarmovienet', 'toonget', 'toonova', 'watch32hd', 'watchseriessto', 'wsunblock', 'zmovies'
    ]
    toggleAll(params['setting'], params['query'], sourcelist)
if mode == "toggleAllForeign":
    sourcelist = ['cinemay', 'dadyflix', 'dpstreaming', 'fullmoviz', 'fullstream', 'skstream', 'streamingseries',
	     'animebase', 'animeloads', 'bs', 'cine', 'ddl', 'filmpalast', 'foxx', 'hdfilme', 'hdstreams', 'horrorkino', 
	     'iload', 'kinow', 'kinox', 'movie2k-ag', 'movie4k', 'moviesever', 'movietown', 'netzkino', 'proxer', 'serienstream',
	     'seriesever', 'stream-to', 'streamdream', 'streamit', 'video4k', 'view4u', 'view4u2', 'gamatotv', 'tainiomania',
	     'tainiesonline', 'xrysoi', 'liomenoi', 'dramabus', 'iheartdrama', 'ikshow', 'myasiantv', 'alltube', 'alltube3d',
	     'boxfilm', 'cdahd', 'cdapl', 'cdax', 'ekinomaniak', 'ekinotv', 'filiser', 'filman', 'filmbit', 'filmdom',
             'filmosy', 'filmowakrainatv', 'filmwebbooster', 'filmy321', 'horrortube', 'iitvx', 'kinonet', 'movieneo',
             'naszekino', 'serialeco', 'szukajkatv', 'exfs', 'filmix', 'newkino', 'pelisplustv', 'pepecine', 'seriespapaya',
             'portalciyiz', 'sezonlukdizi'
    ]
    toggleAll(params['setting'], params['query'], sourcelist)

if mode == "toggleAllDirect":
    sourcelist = ['d1dldrm', 'dl2dlb3d', 'dl3dlb3d', 'dl3f2m', 'dl4dlb3d', 'dl4lavinmovie', 'dl5dlb3d', 'dl5f2m',
                  'dl6dlb3d', 'dl6f2m', 'dl7dlb3d', 'dl7f2m', 'dl7lavinmovie', 'dl8dlb3d', 'dl8lavinmovie', 'dl12dlb3d',
                  'dldlb3d', 'dlmeliupload', 'dlmyfilm', 'dlsitemovie', 'dlsrvdl', 'gmovies',
                  'pz10028', 'pz10093', 's1dlserver', 's1tinydl', 's2dlserver', 's19bitdl', 'stgpz10139']
    toggleAll(params['setting'], params['query'], sourcelist)

if mode == "toggleAllDebrid":
    sourcelist = ['0day', '2ddl', '300mbdownload', '300mbfilms', 'bestmoviez', 'ddlspot', 'ddlvalley',
            'directdl', 'maxrls', 'moviesleak', 'mvrls', 'rlsb', 'rlsbb', 'sceneddl', 'scenerls', 'tvdownload',
            'ultrahdindir', 'warezmovies'
    ]
    toggleAll(params['setting'], params['query'], sourcelist)

if mode == "toggleAllTorrent":
    sourcelist = ['111ys', '1337x', 'btscene', 'doublr', 'eztv', 'glodls', 'kickass2', 'limetorr', 'magnetdl',
            'mkvcage', 'piratebay', 'skytorrents', 'torrapi', 'torrdown', 'torrentquest', 'xpause', 'yifyddl',
            'ytsam', 'zoogle'
    ]
    toggleAll(params['setting'], params['query'], sourcelist)
#########################################################################################################################################################



elif action == "toggleAllNormal":
    sourcelist = []
    sourceList = sources_cy4rootscrapers.all_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.cy4rootscrapers")


elif action == "toggleAllSpares":
    sourcelist = []
    sourceList = sources_cy4rootscrapers.hoster_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Hoster providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.cy4rootscrapers")


elif action == "toggleAllForeign":
    sourcelist = []
    sourceList = sources_cy4rootscrapers.all_foreign_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Foregin providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.cy4rootscrapers")


elif action == "toggleAllDebrid":
    sourcelist = []
    sourceList = sources_cy4rootscrapers.spanish_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Spanish providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.cy4rootscrapers")


elif action == "toggleAllTorrent":
    sourcelist = []
    sourceList = sources_cy4rootscrapers.german_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All German providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.cy4rootscrapers")

########################### stop
elif action == "toggleAllGreek":
    sourcelist = []
    sourceList = sources_cy4rootscrapers.greek_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Greek providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.cy4rootscrapers")


elif action == "toggleAllPolish":
    sourcelist = []
    sourceList = sources_cy4rootscrapers.polish_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Polish providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.cy4rootscrapers")


elif action == "toggleAllPaid":
    sourcelist = []
    sourceList = sources_cy4rootscrapers.all_paid_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Paid providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.cy4rootscrapers")


elif action == "toggleAllDebrid":
    sourcelist = []
    sourceList = sources_cy4rootscrapers.debrid_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Debrid providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.cy4rootscrapers")


elif action == "toggleAllTorrent":
    sourcelist = []
    sourceList = sources_cy4rootscrapers.torrent_providers
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    #    xbmc.log('All Torrent providers = %s' % sourceList,2)
    control.openSettings(query, "script.module.cy4rootscrapers")

if action == "Defaults":
    sourceList = ['1putlocker', '123movieshubz', 'animetoon', 'azmovie', 'bnwmovies',
                  'cartoonhd', 'cmovieshd', 'coolmoviezone', 'deepmovie', 'divxcrawler', 'extramovies', 'fmoviesio',
                  'freefmovies',
                  'gomoviesink', 'gowatchseries', 'hdmto', 'hdpopcorneu', 'iwaatch', 'iwannawatch',
                  'library', 'movie4kis', 'mycouchtuner', 'myhdpopcorn', 'onlineseries', 'primewire',
                  'projectfreetv', 'putlockerfree', 'putlockeronl', 'seehd', 'series9', 'seriesonline', 'sezonlukdizi',
                  'sharemovies', 'solarmoviefree', 'streamdreams', 'swatchseries', 'timewatch', 'toonget',
                  'tvbox', 'watchepisodes', 'watchserieshd', 'wnmnt', 'xwatchseries', 'yesmoviesgg',
                  '2ddl', '300mbdownload', '300mbfilms', 'ddlspot', 'directdl', 'ganool',
                  'maxrls', 'moviesleak', 'mvrls', 'myvideolink', 'rapidmoviez', 'rlsbb', 'sceneddl', 'scenerls',
                  'scenerlscom', 'ultrahd',
                  'warezmovies', '1337x', 'btdb', 'btscene', 'digbt', 'doublr', 'eztv', 'glodls', 'kickass2',
                  'limetorrents',
                  'magnetdl', 'mkvcage', 'piratebay', 'torrentapi', 'torrentdownloads', 'yify',
                  'yifyddl',
                  'ytsam', 'zoogle']
    for i in sourceList:
        source_setting = 'provider.' + i
        control.setSetting(source_setting, params['setting'])
    control.openSettings(query, "script.module.cy4rootscrapers")
